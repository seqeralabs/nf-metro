"""Bridge detection for non-merging line crossings.

Two distinct metro lines may cross at a point that is *not* a shared
station, port, junction, or merge.  Drawn naively that reads as an
interchange.  A *bridge* disambiguates it: the lines of the "under" bundle
are interrupted by a short gap where they pass beneath the continuous
"over" bundle.

This module is the detection half: it finds genuine non-merging crossings
on the *rendered* polylines (offsets already applied) and reports, per
under-route, the gap span to break.  The drawing half lives in ``svg.py``.

A crossing is genuine only when:

* the two lines differ;
* the two crossing edges share no endpoint node, and (when same-line) are not
  a fan-out/fan-in (legs that both fork from a shared ancestor and rejoin on a
  shared descendant); same-line legs with no common ancestor that only meet
  again at the common sink are independent arms that genuinely cross;
* the intersection is not within ``BRIDGE_NODE_TOLERANCE`` of any node the
  layout places (interchanges happen *at* nodes);
* the two segments are not near-parallel (offset bundle slivers barely
  intersect but do not visually cross);
* the under-line has room to break clear of its smoothed corners.

Crossings are grouped into clusters (one bundle crossing another counts as
one event).  Within a cluster the routes split cleanly into two bundles
(a 2-colouring of the crossing graph); every line of the *under* bundle is
broken by a single gap spanning the full width of the *over* bundle, so a
bundle reads as passing under as a whole rather than line by line.

A cluster is bridged only when the two bundles **share a colour** (line):
when every colour differs the lines already read as distinct where they
cross, so a gap adds nothing; a bridge earns its keep only when a shared
colour could otherwise look like it joins or interchanges at the crossing.

Over/under is decided per cluster: when the two bundles use different lines
the senior (earlier-defined) bundle stays over, matching paint order; when
they share lines (e.g. a vertical merge bus crossing its own horizontal
connector) the more-horizontal bundle goes under, so the continuous bus is
not chopped at every connector it crosses.
"""

from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

import networkx as nx

from nf_metro.graph_views import line_graphs
from nf_metro.layout.routing.corners import resolve_curve_radii
from nf_metro.parser.model import Edge, MetroGraph

if TYPE_CHECKING:
    from nf_metro.layout.routing.common import RoutedPath
from nf_metro.render.constants import (
    BRIDGE_CLUSTER_RADIUS,
    BRIDGE_CORNER_CLEARANCE,
    BRIDGE_GAP_HALF,
    BRIDGE_JOIN_TOLERANCE,
    BRIDGE_MIN_ANGLE_DEG,
    BRIDGE_NODE_TOLERANCE,
)

__all__ = ["BridgeBreak", "compute_bridges"]

Point = tuple[float, float]


@dataclass(frozen=True)
class BridgeBreak:
    """A gap on an under-route's polyline where it passes under a crossing.

    The pen lifts between ``cut_a`` and ``cut_b`` (both on the straight run
    of segment ``seg_index``, ``cut_a`` nearer the segment start).
    """

    seg_index: int
    cut_a: Point
    cut_b: Point


@dataclass
class _Crossing:
    """An intersection of route ``a`` (on segment ``seg_a``) with route ``b``
    (on segment ``seg_b``), where ``a``/``b`` are indices into ``routes``."""

    a: int
    seg_a: int
    b: int
    seg_b: int
    point: Point


class BridgeInvariantError(AssertionError):
    """A computed bridge violated a structural invariant."""


def _segment_intersection(p1: Point, p2: Point, p3: Point, p4: Point) -> Point | None:
    """Proper interior intersection of segments p1p2 and p3p4, or None."""
    x1, y1 = p1
    x2, y2 = p2
    x3, y3 = p3
    x4, y4 = p4
    denom = (x2 - x1) * (y4 - y3) - (y2 - y1) * (x4 - x3)
    if abs(denom) < 1e-9:
        return None
    t = ((x3 - x1) * (y4 - y3) - (y3 - y1) * (x4 - x3)) / denom
    u = ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1)) / denom
    eps = 1e-6
    if eps < t < 1 - eps and eps < u < 1 - eps:
        return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
    return None


def _segment_angle_deg(p: Point, q: Point) -> float:
    """Orientation of segment p->q in [0, 180)."""
    return math.degrees(math.atan2(q[1] - p[1], q[0] - p[0])) % 180.0


def _angle_between(a: float, b: float) -> float:
    """Acute angle between two orientations in [0, 90]."""
    diff = abs(a - b) % 180.0
    return min(diff, 180.0 - diff)


def _horizontalness(angle: float) -> float:
    """1 for horizontal, 0 for vertical."""
    return 1.0 - _angle_between(angle, 0.0) / 90.0


def _shares_endpoint(e1: Edge, e2: Edge) -> bool:
    return bool({e1.source, e1.target} & {e2.source, e2.target})


class _LineReachability:
    """Per-line reachability cached only for endpoints bridge detection queries."""

    def __init__(self, graph: MetroGraph) -> None:
        self._views = line_graphs(graph)
        self._descendants: dict[tuple[str, str], frozenset[str]] = {}
        self._ancestors: dict[tuple[str, str], frozenset[str]] = {}

    def descendants(self, line_id: str, node: str) -> frozenset[str]:
        key = (line_id, node)
        if key not in self._descendants:
            self._descendants[key] = frozenset(
                (node, *nx.descendants(self._views[line_id], node))
            )
        return self._descendants[key]

    def ancestors(self, line_id: str, node: str) -> frozenset[str]:
        key = (line_id, node)
        if key not in self._ancestors:
            self._ancestors[key] = frozenset(
                (node, *nx.ancestors(self._views[line_id], node))
            )
        return self._ancestors[key]


def _line_reachability(graph: MetroGraph) -> _LineReachability:
    return _LineReachability(graph)


def _same_line_is_fan(
    e1: Edge,
    e2: Edge,
    line_reachability: _LineReachability,
) -> bool:
    """True when two same-line edges are one fan-out/fan-in rather than a
    genuine crossover.

    A fan is a fork-and-rejoin: the legs diverge from a shared ancestor on the
    line *and* reconverge on a shared descendant.  The original test checked
    only the rejoin, but in a convergence everything rejoins at the common sink
    - so two independent arms (no shared ancestor, meeting only far downstream)
    were misread as a fan.  Requiring a shared *fork* as well separates them:
    independent arms lack a common ancestor (or rejoin only at the sink with no
    fork), so they read as a genuine crossover and earn a bridge.

    Edges sharing an endpoint are trivially one fork/join.  Otherwise both a
    common ancestor (fork) and a common descendant (rejoin) on the line must
    exist; reconvergence alone is not enough."""
    if _shares_endpoint(e1, e2):
        return True
    line_id = e1.line_id
    rejoins = not line_reachability.descendants(line_id, e1.target).isdisjoint(
        line_reachability.descendants(line_id, e2.target)
    )
    forks = not line_reachability.ancestors(line_id, e1.source).isdisjoint(
        line_reachability.ancestors(line_id, e2.source)
    )
    return rejoins and forks


def _near_node(pt: Point, node_xy: list[Point]) -> bool:
    return any(
        abs(pt[0] - nx) < BRIDGE_NODE_TOLERANCE
        and abs(pt[1] - ny) < BRIDGE_NODE_TOLERANCE
        for nx, ny in node_xy
    )


def compute_bridges(
    graph: MetroGraph,
    routes: list[RoutedPath],
    polylines: list[list[Point]],
    *,
    curve_radius: float,
    curve_radii: Sequence[Sequence[float] | None] | None = None,
) -> dict[int, list[BridgeBreak]]:
    """Find non-merging crossings and report per-under-route gap spans.

    ``routes`` and ``polylines`` are aligned: ``polylines[i]`` is the
    offset-applied geometry actually drawn for ``routes[i]``.  Returns a map
    from ``id(route)`` of each under-route to the gaps to break on it.
    """
    drawable_radii: Sequence[Sequence[float] | None]
    if curve_radii is None:
        drawable_radii = [route.curve_radii for route in routes]
    else:
        if len(curve_radii) != len(routes):
            raise ValueError("routes and curve_radii must be aligned")
        drawable_radii = curve_radii

    node_pos = {s.id: (s.x, s.y) for s in graph.stations.values()}
    node_xy = list(node_pos.values())
    station_xy = {
        s.id: (s.x, s.y)
        for s in graph.stations.values()
        if not s.is_port and not s.is_hidden and not s.id.startswith("__")
    }
    line_reachability = _line_reachability(graph)
    crossings = _find_crossings(
        routes, polylines, node_pos, station_xy, line_reachability
    )
    clusters = _cluster_crossings(crossings)

    line_priority = {lid: i for i, lid in enumerate(graph.lines)}
    by_line: dict[str, list[int]] = defaultdict(list)
    for idx, r in enumerate(routes):
        by_line[r.line_id].append(idx)

    breaks: dict[int, list[BridgeBreak]] = defaultdict(list)
    seen: dict[int, set[tuple[int, int, int, int, int]]] = defaultdict(set)

    def add(route_idx: int, seg: int, span: tuple[Point, Point]) -> None:
        key = (
            seg,
            round(span[0][0]),
            round(span[0][1]),
            round(span[1][0]),
            round(span[1][1]),
        )
        if key in seen[route_idx]:
            return
        seen[route_idx].add(key)
        breaks[id(routes[route_idx])].append(
            BridgeBreak(seg_index=seg, cut_a=span[0], cut_b=span[1])
        )

    for cluster in clusters:
        for route_idx, seg, span in _cluster_gaps(
            cluster,
            routes,
            polylines,
            drawable_radii,
            line_priority,
            curve_radius,
        ):
            # Break every collinear route of this line through the span, not
            # just the one that crossed - sibling routes (same line, same
            # corridor) would otherwise fill the gap and hide the break.
            line_id = routes[route_idx].line_id
            for sib in by_line[line_id]:
                sib_seg = _segment_containing(
                    polylines[sib],
                    span,
                    curve_radius,
                    drawable_radii[sib],
                )
                if sib_seg is not None:
                    add(sib, sib_seg, span)

    result = dict(breaks)
    _guard_bridges(routes, polylines, node_xy, result)
    return result


def _guard_bridges(
    routes: list[RoutedPath],
    polylines: list[list[Point]],
    node_xy: list[Point],
    breaks: dict[int, list[BridgeBreak]],
) -> None:
    """Fail loudly if a bridge lands on a node (an interchange, not a
    crossing) or its gap is not collinear with the segment it breaks."""
    poly_by_id = {id(r): p for r, p in zip(routes, polylines)}
    for rid, bk_list in breaks.items():
        poly = poly_by_id[rid]
        for bk in bk_list:
            mx = (bk.cut_a[0] + bk.cut_b[0]) / 2
            my = (bk.cut_a[1] + bk.cut_b[1]) / 2
            if _near_node((mx, my), node_xy):
                raise BridgeInvariantError(
                    f"bridge gap at ({mx:.0f},{my:.0f}) sits on a node - "
                    "interchanges must not be bridged"
                )
            a, b = poly[bk.seg_index], poly[bk.seg_index + 1]
            for pt in (bk.cut_a, bk.cut_b):
                if not _point_on_segment(pt, a, b, 0.0):
                    raise BridgeInvariantError(
                        f"bridge gap end {pt} is not on segment "
                        f"{bk.seg_index} of its route"
                    )


def _find_crossings(
    routes: list[RoutedPath],
    polylines: list[list[Point]],
    node_pos: dict[str, Point],
    station_xy: dict[str, Point],
    line_reachability: _LineReachability,
) -> list[_Crossing]:
    """All genuine non-merging segment crossings.

    Crossings between distinct lines always qualify (subject to the node/join
    /angle filters below).  Same-line crossings qualify only when the two
    routes are independent legs heading to separate destinations (a genuine
    crossover); same-line crossings that are a fan-out/fan-in/loop reordering
    are skipped (``_same_line_is_fan``) since their legs belong to one fork and
    rejoin rather than cross.  The one exception: legs that share the fork/join
    node yet re-cross far from it, which a shared endpoint cannot explain and so
    reads as a genuine crossover (``_fan_recrosses_far_from_node``)."""
    node_xy = list(node_pos.values())
    out: list[_Crossing] = []
    for a in range(len(routes)):
        ra, pa = routes[a], polylines[a]
        for b in range(a + 1, len(routes)):
            rb, pb = routes[b], polylines[b]
            same_line = ra.line_id == rb.line_id
            shares = _shares_endpoint(ra.edge, rb.edge)
            if shares and not same_line:
                continue
            is_fan = same_line and _same_line_is_fan(
                ra.edge, rb.edge, line_reachability
            )
            shared_nodes = (
                {ra.edge.source, ra.edge.target} & {rb.edge.source, rb.edge.target}
                if is_fan
                else set()
            )
            endpoints = (ra.edge.source, ra.edge.target, rb.edge.source, rb.edge.target)
            for i in range(len(pa) - 1):
                for j in range(len(pb) - 1):
                    pt = _segment_intersection(pa[i], pa[i + 1], pb[j], pb[j + 1])
                    if pt is None or _near_node(pt, node_xy):
                        continue
                    if _near_join(pt, endpoints, station_xy):
                        continue
                    if is_fan and not _fan_recrosses_far_from_node(
                        pt, shared_nodes, node_pos
                    ):
                        continue
                    ang = _angle_between(
                        _segment_angle_deg(pa[i], pa[i + 1]),
                        _segment_angle_deg(pb[j], pb[j + 1]),
                    )
                    if ang < BRIDGE_MIN_ANGLE_DEG:
                        continue
                    out.append(_Crossing(a=a, seg_a=i, b=b, seg_b=j, point=pt))
    return out


def _fan_recrosses_far_from_node(
    pt: Point, shared_nodes: set[str], node_pos: dict[str, Point]
) -> bool:
    """True when a fan's crossing is a genuine crossover to bridge, not the
    fork/join itself.

    A shared endpoint accounts for the two legs meeting only in the
    neighbourhood of that node; a re-cross far from it, in open space, is a
    real crossover.  Legs that fork/join without a shared node (reconvergence
    only) have nothing to re-cross far from, so their crossing is never a
    crossover."""
    return bool(shared_nodes) and not _near_any(pt, shared_nodes, node_pos)


def _near_any(pt: Point, node_ids: Iterable[str], positions: dict[str, Point]) -> bool:
    """True if ``pt`` is within ``BRIDGE_JOIN_TOLERANCE`` of any named node."""
    return any(
        (nxy := positions.get(nid)) is not None
        and math.hypot(pt[0] - nxy[0], pt[1] - nxy[1]) < BRIDGE_JOIN_TOLERANCE
        for nid in node_ids
    )


def _near_join(
    pt: Point, endpoints: tuple[str, ...], station_xy: dict[str, Point]
) -> bool:
    """True if the crossing is the approach to a real station where one of the
    crossing lines joins/branches - a join, not a crossover."""
    return _near_any(pt, endpoints, station_xy)


def _cluster_crossings(crossings: list[_Crossing]) -> list[list[_Crossing]]:
    """Group crossings whose points lie within ``BRIDGE_CLUSTER_RADIUS``."""
    proximity: nx.Graph[int] = nx.Graph()
    proximity.add_nodes_from(range(len(crossings)))
    for i in range(len(crossings)):
        for j in range(i + 1, len(crossings)):
            pi, pj = crossings[i].point, crossings[j].point
            if (
                abs(pi[0] - pj[0]) <= BRIDGE_CLUSTER_RADIUS
                and abs(pi[1] - pj[1]) <= BRIDGE_CLUSTER_RADIUS
            ):
                proximity.add_edge(i, j)
    return [
        [crossings[index] for index in sorted(component)]
        for component in nx.connected_components(proximity)
    ]


def _crossing_graph(
    cluster: list[_Crossing],
    routes: list[RoutedPath],
    *,
    same_line_only: bool = False,
) -> tuple[nx.Graph[int], dict[int, int]]:
    """Build a cluster's crossing graph and route-to-segment map.

    With ``same_line_only`` the distinct-line crossings are dropped: they never
    bridge, and a third line cornering through a same-line crossover can only
    skew the over/under colouring."""
    graph: nx.Graph[int] = nx.Graph()
    seg_of: dict[int, int] = {}
    for c in cluster:
        if same_line_only and routes[c.a].line_id != routes[c.b].line_id:
            continue
        graph.add_edge(c.a, c.b)
        seg_of[c.a] = c.seg_a
        seg_of[c.b] = c.seg_b
    return graph, seg_of


def _two_colour(graph: nx.Graph[int]) -> dict[int, int] | None:
    """2-colour the crossing graph; None if it is not bipartite."""
    ordered: nx.Graph[int] = nx.Graph()
    ordered.add_nodes_from(sorted(graph))
    ordered.add_edges_from(graph.edges)
    try:
        return {
            node: colour ^ 1 for node, colour in nx.bipartite.color(ordered).items()
        }
    except nx.NetworkXError:
        return None


Gap = tuple[Point, Point]


def _cluster_gaps(
    cluster: list[_Crossing],
    routes: list[RoutedPath],
    polylines: list[list[Point]],
    curve_radii: Sequence[Sequence[float] | None],
    line_priority: dict[str, int],
    curve_radius: float,
) -> list[tuple[int, int, Gap]]:
    """For one cluster, return (route_index, seg_index, gap) for every line of
    the under bundle.  The gap is the same span (in the shared crossing
    direction) for all parallel under-lines, so the bundle breaks with one
    aligned, uniform-width gap rather than ragged per-line gaps."""
    crossing_graph, seg_of = _crossing_graph(cluster, routes)

    colour = _two_colour(crossing_graph)
    if colour is None:
        # A distinct-line crossing (a third line cornering through a same-line
        # crossover) can form an odd cycle with it, leaving the full graph
        # non-bipartite.  Distinct-line crossings never bridge - colour reads
        # them apart - so recolour on the same-line crossings alone; the
        # spectator lines drop out of the over/under split.
        crossing_graph, seg_of = _crossing_graph(cluster, routes, same_line_only=True)
        colour = _two_colour(crossing_graph)
        if not crossing_graph or colour is None:
            # No same-line crossing, or 3+ same-line arms mutually crossing:
            # no clean over/under split.
            return []

    group = {
        0: [n for n in crossing_graph if colour[n] == 0],
        1: [n for n in crossing_graph if colour[n] == 1],
    }
    under, lines_under, lines_over = _under_group(
        group, routes, polylines, line_priority, seg_of
    )
    over = set(crossing_graph) - under

    # Only bridge where the two bundles share a colour.  When all the colours
    # differ the lines already read as distinct where they cross, so a gap
    # adds nothing; a bridge earns its keep only when a shared colour would
    # otherwise look like it might join/interchange at the crossing.
    if lines_under.isdisjoint(lines_over):
        return []

    cross_pts = [
        c.point
        for c in cluster
        if (c.a in under and c.b in over) or (c.b in under and c.a in over)
    ]
    if not cross_pts:
        return []
    return _uniform_gaps(
        sorted(under),
        seg_of,
        polylines,
        curve_radii,
        cross_pts,
        curve_radius,
    )


def _uniform_gaps(
    under: list[int],
    seg_of: dict[int, int],
    polylines: list[list[Point]],
    curve_radii: Sequence[Sequence[float] | None],
    cross_pts: list[Point],
    curve_radius: float,
) -> list[tuple[int, int, Gap]]:
    """Break every under-line at the same gap, centred on the over bundle.

    The gap is centred on the crossing midpoint and given equal padding on
    both sides; corner clearance shrinks both sides by the same amount (the
    most-constrained under-line decides), so the gap stays symmetric about
    the over-line and identical across the bundle rather than ragged."""
    rep = polylines[under[0]]
    rseg = seg_of[under[0]]
    ux, uy = _unit(rep[rseg], rep[rseg + 1])
    projs = [p[0] * ux + p[1] * uy for p in cross_pts]
    cmin, cmax = min(projs), max(projs)
    centre = (cmin + cmax) / 2.0
    over_half = (cmax - cmin) / 2.0

    geom = []
    sym_half = over_half + BRIDGE_GAP_HALF
    for ri in under:
        seg = seg_of[ri]
        poly = polylines[ri]
        a, b = poly[seg], poly[seg + 1]
        seg_len = math.hypot(b[0] - a[0], b[1] - a[1])
        if seg_len == 0:
            continue
        a_u = a[0] * ux + a[1] * uy
        run_lo, run_hi = _run_projection_limits(
            poly, curve_radii[ri], seg, ux, uy, curve_radius
        )
        sym_half = min(
            sym_half,
            centre - run_lo,
            run_hi - centre,
        )
        geom.append(
            (
                ri,
                a,
                (b[0] - a[0]) / seg_len,
                (b[1] - a[1]) / seg_len,
                a_u,
                run_lo,
                run_hi,
            )
        )

    # Prefer a gap centred on the over bundle (symmetric, identical across the
    # bundle).  Where a segment is too short to centre a covering gap, fall
    # back to clamping each line independently so the crossing still breaks.
    symmetric = sym_half >= over_half and sym_half > 0

    out: list[tuple[int, int, Gap]] = []
    for ri, a, sux, suy, a_u, run_lo, run_hi in geom:
        if symmetric:
            lo_s = centre - sym_half - a_u
            hi_s = centre + sym_half - a_u
        else:
            lo_s = max(run_lo - a_u, cmin - a_u - BRIDGE_GAP_HALF)
            hi_s = min(run_hi - a_u, cmax - a_u + BRIDGE_GAP_HALF)
            if lo_s >= hi_s:
                continue
        span = (
            (a[0] + sux * lo_s, a[1] + suy * lo_s),
            (a[0] + sux * hi_s, a[1] + suy * hi_s),
        )
        member_seg = _member_segment_containing(polylines[ri], span)
        if member_seg is None:
            continue
        out.append(
            (
                ri,
                member_seg,
                span,
            )
        )
    return out


def _under_group(
    group: dict[int, list[int]],
    routes: list[RoutedPath],
    polylines: list[list[Point]],
    line_priority: dict[str, int],
    seg_of: dict[int, int],
) -> tuple[set[int], set[str], set[str]]:
    """Pick the under bundle; return its route indices and the two bundles'
    colour (line-id) sets as ``(under, lines_under, lines_over)``."""
    colours = {
        0: {routes[n].line_id for n in group[0]},
        1: {routes[n].line_id for n in group[1]},
    }
    back = len(line_priority)

    def min_prio(lines: set[str]) -> int:
        return min((line_priority.get(lid, back) for lid in lines), default=back)

    if colours[0].isdisjoint(colours[1]):
        # Distinct lines: senior (earlier-defined) bundle stays over.
        under_colour = 1 if min_prio(colours[0]) <= min_prio(colours[1]) else 0
    else:
        # Shared lines (e.g. a vertical bus crossing its own horizontal
        # connector): the more-horizontal bundle goes under, so the
        # continuous bus is not chopped at every connector it crosses.
        h0 = _group_horizontalness(group[0], polylines, seg_of)
        h1 = _group_horizontalness(group[1], polylines, seg_of)
        under_colour = 0 if h0 >= h1 else 1
    return set(group[under_colour]), colours[under_colour], colours[under_colour ^ 1]


def _group_horizontalness(
    members: list[int], polylines: list[list[Point]], seg_of: dict[int, int]
) -> float:
    if not members:
        return 0.0
    total = 0.0
    for n in members:
        seg = seg_of[n]
        p = polylines[n]
        total += _horizontalness(_segment_angle_deg(p[seg], p[seg + 1]))
    return total / len(members)


def _unit(a: Point, b: Point) -> Point:
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    return (dx / length, dy / length) if length else (1.0, 0.0)


def _segments_continue_straight(a: Point, b: Point, c: Point) -> bool:
    ab = (b[0] - a[0], b[1] - a[1])
    bc = (c[0] - b[0], c[1] - b[1])
    return (
        math.hypot(*ab) > 1e-9
        and math.hypot(*bc) > 1e-9
        and abs(ab[0] * bc[1] - ab[1] * bc[0]) <= 1e-6
        and ab[0] * bc[0] + ab[1] * bc[1] > 0.0
    )


def _maximal_collinear_run(poly: list[Point], seg: int) -> tuple[int, int]:
    start = seg
    while start > 0 and _segments_continue_straight(
        poly[start - 1], poly[start], poly[start + 1]
    ):
        start -= 1
    end = seg + 1
    while end < len(poly) - 1 and _segments_continue_straight(
        poly[end - 1], poly[end], poly[end + 1]
    ):
        end += 1
    return start, end


def _rounded_corner_clearances(
    poly: list[Point],
    curve_radii: Sequence[float] | None,
    start: int,
    end: int,
    curve_radius: float,
) -> tuple[float, float]:
    resolved = resolve_curve_radii(
        poly,
        None if curve_radii is None else list(curve_radii),
        default_radius=curve_radius,
    )

    def clearance(point_idx: int) -> float:
        if point_idx <= 0 or point_idx >= len(poly) - 1:
            return 0.0
        incoming = (
            poly[point_idx][0] - poly[point_idx - 1][0],
            poly[point_idx][1] - poly[point_idx - 1][1],
        )
        outgoing = (
            poly[point_idx + 1][0] - poly[point_idx][0],
            poly[point_idx + 1][1] - poly[point_idx][1],
        )
        if abs(incoming[0] * outgoing[1] - incoming[1] * outgoing[0]) <= 1e-9:
            return 0.0
        radius = resolved[point_idx - 1]
        if radius <= 1e-9:
            return 0.0
        return radius + BRIDGE_CORNER_CLEARANCE

    return clearance(start), clearance(end)


def _run_projection_limits(
    poly: list[Point],
    curve_radii: Sequence[float] | None,
    seg: int,
    ux: float,
    uy: float,
    curve_radius: float,
) -> tuple[float, float]:
    start, end = _maximal_collinear_run(poly, seg)
    start_u = poly[start][0] * ux + poly[start][1] * uy
    end_u = poly[end][0] * ux + poly[end][1] * uy
    start_clear, end_clear = _rounded_corner_clearances(
        poly, curve_radii, start, end, curve_radius
    )
    if start_u <= end_u:
        return start_u + start_clear, end_u - end_clear
    return end_u + end_clear, start_u - start_clear


def _member_segment_containing(poly: list[Point], span: Gap) -> int | None:
    a, b = span
    for i in range(len(poly) - 1):
        if _point_on_segment(a, poly[i], poly[i + 1], 0.0) and _point_on_segment(
            b, poly[i], poly[i + 1], 0.0
        ):
            return i
    return None


def _segment_containing(
    poly: list[Point],
    span: tuple[Point, Point],
    curve_radius: float,
    curve_radii: Sequence[float] | None = None,
) -> int | None:
    """Index of the segment of ``poly`` that contains the gap ``span``
    collinearly and clear of its corners, or None."""
    seg = _member_segment_containing(poly, span)
    if seg is None:
        return None
    ux, uy = _unit(poly[seg], poly[seg + 1])
    run_lo, run_hi = _run_projection_limits(
        poly, curve_radii, seg, ux, uy, curve_radius
    )
    span_projections = [point[0] * ux + point[1] * uy for point in span]
    if min(span_projections) < run_lo or max(span_projections) > run_hi:
        return None
    return seg


def _point_on_segment(pt: Point, p: Point, q: Point, corner_clear: float) -> bool:
    """True if ``pt`` lies on segment p->q (within 1px perpendicular) and at
    least ``corner_clear`` from either end."""
    dx, dy = q[0] - p[0], q[1] - p[1]
    length = math.hypot(dx, dy)
    if length == 0:
        return False
    ux, uy = dx / length, dy / length
    proj = (pt[0] - p[0]) * ux + (pt[1] - p[1]) * uy
    if proj < corner_clear or proj > length - corner_clear:
        return False
    perp = abs((pt[0] - p[0]) * (-uy) + (pt[1] - p[1]) * ux)
    return perp <= 1.0
