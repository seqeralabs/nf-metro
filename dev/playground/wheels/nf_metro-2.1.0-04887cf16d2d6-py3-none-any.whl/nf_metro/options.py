"""Single source of truth for layout/render options exposed in both planes.

Every tunable that can be set both by a ``%%metro`` directive and by a CLI
flag is declared once here as a :class:`LayoutOption`. The directive
dispatcher (:mod:`nf_metro.parser.directives`) and the CLI
(:mod:`nf_metro.cli`) each build their surface from this registry, so adding
an option - its name, type, constraints, and help - wires up the directive
handler and the CLI flag together rather than in two hand-kept places.

Each option targets a field on :class:`~nf_metro.parser.model.MetroGraph` of
the same name (or :attr:`LayoutOption.attr`): the directive writes that field
during parsing, an explicitly-set CLI flag overwrites it afterwards, and the
layout engine and renderer read it. Precedence is uniform: CLI flag (when set)
> ``%%metro`` directive > built-in default.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Literal, TypeGuard

# Returned by :func:`coerce` in place of a value when the payload is unusable.
INVALID = object()

OptionKind = Literal["float", "int", "bool", "choice", "str"]
NumberSign = Literal["any", "nonneg", "positive"]
LineOrder = Literal["definition", "span"]
LINE_ORDER_CHOICES: tuple[LineOrder, ...] = ("definition", "span")

#: Station-columns a section row may reach before the auto-layout folds it.
DEFAULT_FOLD_THRESHOLD: int = 15


def is_line_order(value: object) -> TypeGuard[LineOrder]:
    """Return whether *value* is a supported line-order policy."""
    return isinstance(value, str) and value in LINE_ORDER_CHOICES


@dataclass(frozen=True)
class LayoutOption:
    """One tunable settable via ``%%metro`` and the equivalent CLI flag.

    ``kind`` selects parsing and the CLI type: ``float``/``int`` numbers
    (constrained by ``sign``), a ``bool`` flag, a ``choice`` from ``choices``,
    or a free ``str``.
    """

    name: str
    kind: OptionKind
    help: str
    attr: str = ""
    choices: tuple[str, ...] = ()
    sign: NumberSign = "any"
    max_val: float | None = None  # inclusive upper bound for numeric options
    parse_time: bool = False  # consumed during parsing, not after
    hidden: bool = False  # omit the generated CLI flag from --help

    @property
    def target_attr(self) -> str:
        """Graph attribute this option writes (defaults to ``name``)."""
        return self.attr or self.name

    @property
    def cli_flag(self) -> str:
        """Long CLI flag for this option (kebab-cased ``name``)."""
        return "--" + self.name.replace("_", "-")


def coerce(opt: LayoutOption, raw: str) -> tuple[Any, str]:
    """Parse a directive payload for *opt*.

    Returns ``(value, "")`` on success or ``(INVALID, expected)`` on failure,
    where *expected* describes the valid input for a warning message.
    """
    text = raw.strip()
    if opt.kind == "bool":
        token = text.lower()
        if token in ("true", "yes", "1"):
            return True, ""
        if token in ("false", "no", "0", ""):
            return False, ""
        return INVALID, "a boolean (true/false)"
    if opt.kind == "choice":
        token = text.lower()
        if token in opt.choices:
            return token, ""
        return INVALID, " or ".join(repr(c) for c in opt.choices)
    if opt.kind in ("int", "float"):
        caster = int if opt.kind == "int" else float
        try:
            num = caster(text)
        except ValueError:
            return INVALID, "a number"
        if not math.isfinite(num):
            return INVALID, "a finite number"
        if opt.sign == "nonneg" and num < 0:
            return INVALID, "a non-negative number"
        if opt.sign == "positive" and num <= 0:
            return INVALID, "a positive number"
        if opt.max_val is not None and num > opt.max_val:
            return INVALID, f"a number <= {opt.max_val}"
        return num, ""
    return text, ""


# Declaration order is the order CLI flags appear in --help.
LAYOUT_OPTIONS: tuple[LayoutOption, ...] = (
    LayoutOption(
        name="x_spacing",
        kind="float",
        sign="positive",
        help="Horizontal spacing between layers.",
    ),
    LayoutOption(
        name="y_spacing",
        kind="float",
        sign="positive",
        help="Vertical spacing between tracks.",
    ),
    LayoutOption(
        name="section_x_gap",
        kind="float",
        sign="nonneg",
        help="Horizontal gap between sections.",
    ),
    LayoutOption(
        name="section_y_gap",
        kind="float",
        sign="nonneg",
        help="Vertical gap between sections.",
    ),
    LayoutOption(
        name="track_gap",
        kind="float",
        sign="nonneg",
        help="Gap in px between adjacent strokes in a bundle.",
        max_val=3.0,
    ),
    LayoutOption(
        name="fold_threshold",
        kind="int",
        sign="positive",
        parse_time=True,
        help="Max station-columns in a section row before it wraps.",
    ),
    LayoutOption(
        name="diamond_style",
        kind="choice",
        choices=("straight", "symmetric"),
        help="Fork-join (diamond) branch layout.",
    ),
    LayoutOption(
        name="line_order",
        kind="choice",
        choices=LINE_ORDER_CHOICES,
        help="Track assignment order for lines.",
    ),
    LayoutOption(
        name="row_align",
        kind="choice",
        choices=("content", "top"),
        help="Section bbox sizing within a grid row.",
    ),
    LayoutOption(
        name="center_ports",
        kind="bool",
        help="Centre inter-section ports on the shorter section.",
    ),
    LayoutOption(
        name="compact_offsets",
        kind="bool",
        help="Size each station for the lines passing through it.",
    ),
    LayoutOption(
        name="label_angle",
        kind="float",
        sign="any",
        help="Station label angle in degrees (0 = horizontal).",
    ),
    LayoutOption(
        name="font_scale",
        kind="float",
        sign="positive",
        help="Scale text sizes and label metrics.",
    ),
    LayoutOption(
        name="stroke_scale",
        kind="float",
        sign="positive",
        help="Scale stroke weight and station pill size.",
    ),
    LayoutOption(
        name="logo_scale",
        kind="float",
        sign="positive",
        help="Scale the logo within the legend block.",
    ),
    LayoutOption(
        name="legend_min_height",
        kind="float",
        sign="nonneg",
        help="Minimum legend content height in px.",
    ),
    LayoutOption(
        name="legend_logo_gap",
        kind="float",
        sign="nonneg",
        help="Gap in px between the logo and the legend entries.",
    ),
    LayoutOption(
        name="width",
        kind="int",
        sign="positive",
        help="Output width in pixels.",
    ),
    LayoutOption(
        name="height",
        kind="int",
        sign="positive",
        help="Output height in pixels.",
    ),
    LayoutOption(
        name="animate",
        kind="bool",
        help="Animate markers travelling along the lines.",
    ),
    LayoutOption(
        name="directional",
        kind="bool",
        help="Draw chevrons showing each route's flow direction.",
    ),
    LayoutOption(
        name="strict",
        kind="bool",
        help="Fail on a layout-invariant violation.",
    ),
    LayoutOption(
        name="permissive",
        kind="bool",
        help="Downgrade guard failures to warnings and continue rendering.",
    ),
    LayoutOption(
        name="auto_process",
        kind="bool",
        parse_time=True,
        help="Default each station's process pattern to its own id.",
    ),
    LayoutOption(
        name="process_scope",
        kind="str",
        parse_time=True,
        help="Prefix shared by the pipeline's processes.",
    ),
    LayoutOption(
        name="manifest",
        attr="embed_manifest",
        kind="bool",
        hidden=True,
        help="Embed the data manifest in the SVG.",
    ),
    LayoutOption(
        name="caption",
        kind="str",
        help="Caption or attribution line, rendered bottom-left.",
    ),
)
