"""Intra-section routing: entry runway, shape dispatch, and in-section diagonals.

``_route_intra_section`` is an ordered dispatch over the distinct shapes an
edge inside (or leaving) a section can take -- a fold gutter, a perpendicular
exit, two straight cases -- with the horizontal-diagonal-horizontal run as the
fall-through.  ``_route_entry_runway`` is a sibling shape kept as its own
ordered local handler in ``core.py`` because it claims an edge before the
section's internal handlers run.
"""

from __future__ import annotations

import math

from nf_metro.layout.constants import (
    COORD_TOLERANCE,
    COORD_TOLERANCE_FINE,
    CROSS_ROW_THRESHOLD,
    CURVE_RADIUS,
    FOLD_MARGIN,
    ICON_TERMINUS_FORK_LEAD,
    LABEL_BBOX_MARGIN,
    MIN_STATION_FLAT_LENGTH,
    MIN_STRAIGHT_EDGE,
    MIN_STRAIGHT_PORT,
    OFF_TRACK_OUTPUT_TAIL,
)
from nf_metro.layout.geometry import (
    diagonal_centreline,
    flow_entry_side,
    lanes_run_along_y,
    segment_intersects_bbox,
    single_corner_centreline,
)
from nf_metro.layout.labels import (
    label_text_width,
)
from nf_metro.layout.pass_metrics import station_radius_approx
from nf_metro.layout.routing.bundle import (
    build_tapered_bundle,
)
from nf_metro.layout.routing.centrelines import (
    gather_member_edges,
)
from nf_metro.layout.routing.common import (
    RoutedPath,
)
from nf_metro.layout.routing.context import (
    _get_offset,
    _RoutingCtx,
    _tb_x_offset,
)
from nf_metro.layout.routing.perp import (
    _perp_riser_lateral,
)
from nf_metro.layout.routing.tb_handlers import (
    _compute_diagonal_placement,
    entry_runway_placement,
)
from nf_metro.parser.model import (
    Edge,
    MetroGraph,
    PortSide,
    Section,
    Station,
    is_bypass_v,
)


def _route_entry_runway(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath | None:
    """Route flow-side entry port -> deep internal station with a runway.

    When a line enters a section but its first internal station is deeper
    than the earliest layer, a plain diagonal would hide the fact that
    the line bypasses the early-layer stations.  Instead, compress the
    diagonal into the entry region and extend a horizontal runway past
    the bypassed stations to the target.  A vertical section's flow-side
    entry is drawn by :func:`_route_flow_side_lane_change` before this runs.
    """
    graph = ctx.graph
    port = graph.ports.get(edge.source)
    if not port or not port.is_entry:
        return None

    section = graph.sections.get(tgt.section_id or "")
    if (
        not section
        or not lanes_run_along_y(section.direction)
        or port.side != flow_entry_side(section.direction)
    ):
        return None

    # Same Y means target is on the trunk track: a plain straight run suffices,
    # unless a same-row non-consumer sits between the port and the target, which
    # the straight run would rake.  Bow over such a blocker instead.
    if abs(src.y - tgt.y) < COORD_TOLERANCE_FINE:
        return _route_entry_bow(edge, src, tgt, ctx, section)

    placement = entry_runway_placement(edge, src, tgt, ctx, section)
    if placement is None:
        return None
    return RoutedPath(
        edge=edge,
        line_id=edge.line_id,
        points=diagonal_centreline(
            section.direction, (src.x, src.y), (tgt.x, tgt.y), *placement
        ),
    )


def _marker_bbox(st: Station) -> tuple[float, float, float, float]:
    """Conservative axis-aligned marker footprint centred on the station."""
    r = station_radius_approx()
    return (st.x - r, st.y - r, st.x + r, st.y + r)


def _bow_clears_markers(
    points: list[tuple[float, float]],
    section_stations: list[Station],
) -> bool:
    """Whether every bow segment stays clear of each station marker.

    Verifies the arced-over blockers (which the apex must pass outside of) and
    every other real station in the bow's x-span, so the detour trades one
    crossing for none.
    """
    footprints = [_marker_bbox(st) for st in section_stations]
    for k in range(len(points) - 1):
        x1, y1 = points[k]
        x2, y2 = points[k + 1]
        for bbox in footprints:
            if segment_intersects_bbox(x1, y1, x2, y2, bbox):
                return False
    return True


def _route_entry_bow(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx, section: Section
) -> RoutedPath | None:
    """Bow a trunk-row entry run over a same-row non-consumer station.

    The entry port lands on the target's trunk track, so a straight run would
    pass through any non-carrying station seated on that row between them.  When
    one or more such blockers exist, arc the line off the trunk (up or down,
    whichever side stays clear), run flat past the blockers, and drop back onto
    the trunk before the target.  Returns ``None`` when there is no blocker or
    no side leaves a verifiable clear detour, so routing falls back to the plain
    straight run and the crossing guard warns if it truly cannot be avoided.
    """
    graph = ctx.graph
    line = edge.line_id
    sx, sy = src.x, src.y
    tx, ty = tgt.x, tgt.y
    lo, hi = min(sx, tx), max(sx, tx)

    port_ids = section.port_ids
    section_stations: list[Station] = []
    blockers: list[Station] = []
    for sid in section.station_ids:
        if sid == edge.target or sid in port_ids:
            continue
        st = graph.stations.get(sid)
        if not st or st.is_port:
            continue
        section_stations.append(st)
        if (
            lo < st.x < hi
            and abs(st.y - sy) < COORD_TOLERANCE_FINE
            and line not in graph.station_lines(sid)
        ):
            blockers.append(st)
    if not blockers:
        return None

    clearance = station_radius_approx() + CURVE_RADIUS
    over_start = min(st.x for st in blockers) - clearance
    over_end = max(st.x for st in blockers) + clearance
    height = station_radius_approx() + CURVE_RADIUS
    min_straight = ctx.curve_radius + MIN_STRAIGHT_PORT

    lead_end = over_start - height
    tail_start = over_end + height
    if lead_end - sx < min_straight or tx - tail_start < min_straight:
        return None
    if over_end - over_start < 2 * ctx.curve_radius:
        return None

    for sign in _bow_side_order(section_stations, blockers, sy, over_start, over_end):
        apex = sy + sign * height
        points = [
            (sx, sy),
            (lead_end, sy),
            (over_start, apex),
            (over_end, apex),
            (tail_start, sy),
            (tx, ty),
        ]
        if _bow_clears_markers(points, section_stations):
            return RoutedPath(edge=edge, line_id=edge.line_id, points=points)
    return None


def _bow_side_order(
    section_stations: list[Station],
    blockers: list[Station],
    trunk_y: float,
    over_start: float,
    over_end: float,
) -> list[int]:
    """Order the bow's two candidate sides, roomier one first.

    Returns bow-direction signs (``-1`` up, ``+1`` down) sorted by how far the
    nearest off-trunk marker in the arc's x-span sits from the trunk, so the
    detour prefers the side with more vertical headroom.
    """
    blocker_ids = {st.id for st in blockers}
    up_gap = down_gap = float("inf")
    for st in section_stations:
        if st.id in blocker_ids:
            continue
        if not (
            over_start - station_radius_approx()
            < st.x
            < over_end + station_radius_approx()
        ):
            continue
        dy = st.y - trunk_y
        if dy < -COORD_TOLERANCE_FINE:
            up_gap = min(up_gap, -dy)
        elif dy > COORD_TOLERANCE_FINE:
            down_gap = min(down_gap, dy)
    return [-1, 1] if up_gap >= down_gap else [1, -1]


def _route_fold_edge(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath | None:
    """Cross-row fold edge: out to the fold gutter, down the row gap, back in.

    A backward, cross-row edge between two sections (the target sits on a lower
    row to the left) routes out past the right edge of the fold column, drops in
    the gutter, and runs back in -- rather than cutting diagonally across the
    intervening rows.  Intra-section RL edges are excluded (they share a section
    and run within it).
    """
    same_section = bool(src.section_id and src.section_id == tgt.section_id)
    dy = tgt.y - src.y
    if not (tgt.x - src.x <= 0 and abs(dy) > CROSS_ROW_THRESHOLD and not same_section):
        return None
    fold_right = ctx.fold_x + FOLD_MARGIN
    return RoutedPath(
        edge=edge,
        line_id=edge.line_id,
        points=[
            (src.x, src.y),
            (fold_right, src.y),
            (fold_right, tgt.y),
            (tgt.x, tgt.y),
        ],
    )


def _route_perp_exit(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath | None:
    """Internal station -> perpendicular (TOP/BOTTOM) exit port on an LR/RL section.

    The line runs along the trunk to the exit X, then turns once and leaves
    vertically.  The corner sits past the trailing station so the line bends
    after the marker rather than through it.  A single line is a plain 3-point
    L; co-travelling lines fan the bend through the bundle builder.
    """
    tgt_port = ctx.graph.ports.get(tgt.id)
    src_section = ctx.graph.sections.get(src.section_id) if src.section_id else None
    if not (
        not src.is_port
        and tgt_port is not None
        and not tgt_port.is_entry
        and tgt_port.side in (PortSide.TOP, PortSide.BOTTOM)
        and src_section is not None
        and src_section.direction in ("LR", "RL")
    ):
        return None
    sibling_count = sum(
        1 for e in ctx.graph.edges_from(edge.source) if e.target == edge.target
    )
    if sibling_count <= 1:
        return RoutedPath(
            edge=edge,
            line_id=edge.line_id,
            points=single_corner_centreline(
                src_section.direction, (src.x, src.y), (tgt.x, tgt.y), flow_first=True
            ),
        )
    return _route_perp_exit_bundle(
        edge, src, tgt, tgt_port.side, ctx, src_section.direction
    )


def _aligned_tb_drop_target(
    ctx: _RoutingCtx, exit_port_id: str, exit_x: float
) -> tuple[str, str] | None:
    """The column-aligned vertical-flow entry this perp exit drops straight into.

    Returns ``(entry_port_id, section_id)`` when *exit_port_id* feeds a
    TOP/BOTTOM entry of a vertical-flow section sharing its X, or ``None``.  The
    descent then continues that section's lane through the port instead of the
    reflected riser the cross-column up-and-over uses.
    """
    for e in ctx.graph.edges_from(exit_port_id):
        entry_port = ctx.graph.ports.get(e.target)
        entry_st = ctx.graph.station_for_edge_target(e)
        if (
            entry_port is not None
            and entry_port.is_entry
            and entry_port.side in (PortSide.TOP, PortSide.BOTTOM)
            and entry_port.section_id in ctx.tb_sections
            and abs(entry_st.x - exit_x) <= COORD_TOLERANCE
        ):
            return e.target, entry_port.section_id
    return None


def _route_perp_exit_bundle(
    edge: Edge,
    src: Station,
    tgt: Station,
    side: PortSide,
    ctx: _RoutingCtx,
    direction: str,
) -> RoutedPath | None:
    """Fan a co-travelling perpendicular-exit bundle along one turning centreline.

    The centreline runs the trunk to the exit X, turns once, and leaves
    vertically::

        (sx, sy) -> (tx, sy) -> (tx, ty)

    Each line is a perpendicular offset of it: the trunk run carries the line's
    source-side render Y and the vertical leg its exit-trunk X (via
    :func:`~nf_metro.layout.routing.perp._perp_riser_lateral`, the shared TOP/BOTTOM
    convention).  :func:`build_tapered_bundle` anchors the bend on the bundle's
    innermost-of-turn line, so the per-line gap stays constant through the corner
    and no inside-of-turn arc pinches below the floor radius.
    """
    sx, sy = src.x, src.y
    tx, ty = tgt.x, tgt.y
    is_top = side == PortSide.TOP
    _member_edges, line_ids, _edge_by_line = gather_member_edges(ctx.graph, edge)

    # The trunk run turns +/-x to the exit X; on an RL section the builder's
    # right-hand normal flips the run's per-line render Y, so the source offset
    # carries that leg's travel sign.
    hsign = 1.0 if tx >= sx else -1.0

    # A column-aligned drop into a vertical-flow section continues that section's
    # rotation lane straight through the port, so the leave seats on the target's
    # lane rather than the perp riser's reflection (which the up-and-over needs).
    tb_drop = _aligned_tb_drop_target(ctx, edge.target, tx)

    def source_offset(line_id: str) -> float:
        return _get_offset(ctx, edge.source, line_id) * hsign

    def exit_offset(line_id: str) -> float:
        # The vertical leave seats each line on the exit trunk's per-line X; the
        # right-hand normal reverses a BOTTOM (descending) leg, so the lateral is
        # negated there to cancel it back.
        if tb_drop is not None:
            entry_id, tb_sec = tb_drop
            d = _tb_x_offset(ctx, entry_id, line_id, tb_sec)
        else:
            d = _perp_riser_lateral(ctx, edge.target, line_id, side)
        return d if is_top else -d

    routes = build_tapered_bundle(
        [(edge, edge.line_id, source_offset(edge.line_id), exit_offset(edge.line_id))],
        single_corner_centreline(direction, (sx, sy), (tx, ty), flow_first=True),
        transition_leg=1,
        base_radius=ctx.curve_radius,
        bundle_offsets=[(source_offset(lid), exit_offset(lid)) for lid in line_ids],
        is_inter_section=False,
        normalize_exempt=False,
    )
    return next((r for r in routes if r.line_id == edge.line_id), None)


def _route_same_track_straight(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath | None:
    """Endpoints on one track (shared Y): a straight segment."""
    if abs(src.y - tgt.y) >= COORD_TOLERANCE_FINE:
        return None
    return RoutedPath(
        edge=edge, line_id=edge.line_id, points=[(src.x, src.y), (tgt.x, tgt.y)]
    )


def _route_planned_lane_transition(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath | None:
    """Realise the exit planner's hand-off on an otherwise straight edge."""
    from nf_metro.layout.routing.exit_turns import route_planned_lane_transition

    return route_planned_lane_transition(
        edge,
        ctx,
        is_inter_section=False,
    )


def _route_near_zero_gap_straight(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath | None:
    """Endpoints all but stacked (near-zero X gap): a straight segment."""
    if abs(tgt.x - src.x) >= COORD_TOLERANCE:
        return None
    return RoutedPath(
        edge=edge, line_id=edge.line_id, points=[(src.x, src.y), (tgt.x, tgt.y)]
    )


# Intra-section shape dispatch.  The first shape that claims the edge owns the
# route; order is significant (earlier shapes shadow later ones).  The
# horizontal-diagonal-horizontal run in ``_route_diagonal`` is the fall-through
# when no shape claims the edge.
_INTRA_SECTION_SHAPES = (
    _route_fold_edge,
    _route_perp_exit,
    _route_planned_lane_transition,
    _route_same_track_straight,
    _route_near_zero_gap_straight,
)


def _route_intra_section(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath | None:
    """Route an intra-section edge via the first shape that claims it.

    Each shape in :data:`_INTRA_SECTION_SHAPES` returns a :class:`RoutedPath`
    when it owns the edge or ``None`` to pass; :func:`_route_diagonal` is the
    fall-through.
    """
    for shape in _INTRA_SECTION_SHAPES:
        result = shape(edge, src, tgt, ctx)
        if result is not None:
            return result
    return _route_diagonal(edge, src, tgt, ctx)


def _is_side_branch_ascent(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> bool:
    """Return True for a side-branch edge climbing to the section trunk.

    A side-branch ascent edge starts at a non-port internal station
    sitting off the section's trunk Y, with target either an exit port
    of the same section or another internal station on the trunk Y.
    Visually we want the line to stay on the side-branch track until
    just before the target, so the bundle ordering inside the section
    stays meaningful (the side-branch line does not appear to merge
    with the main trunk bundle mid-section).

    Fires for non-port sources feeding the trunk bundle's join station (single
    line only) or exiting via a shared exit port.  A multi-line exit ascent
    counts only when the source is fed solely from the section boundary (a
    genuine parallel branch); a multi-line node with an in-section predecessor
    is a trunk continuation momentarily dipping below trunk Y, not a branch.
    """
    if src.is_port or src.section_id is None:
        return False
    sec_id = src.section_id
    trunk_y = ctx.section_trunk_y.get(sec_id)
    if trunk_y is None:
        return False
    trunk_tol = ctx.offset_step * 2
    if abs(src.y - trunk_y) < trunk_tol:
        return False  # source is on the trunk; not a side branch
    if abs(tgt.y - trunk_y) >= trunk_tol:
        return False  # target is not on the trunk bundle
    tgt_port = ctx.graph.ports.get(edge.target)
    same_sec = tgt.section_id == sec_id and not tgt.is_port
    is_exit_port = (
        tgt_port is not None and not tgt_port.is_entry and tgt_port.section_id == sec_id
    )
    if not (same_sec or is_exit_port):
        return False
    if len(ctx.graph.station_lines(edge.source)) > 1:
        # A single-line side branch always rides its own track.  A multi-line
        # source is a branch only when it exits via the port AND is fed solely
        # from the section boundary (entry port / inter-section edge): a
        # multi-line node fed by an in-section station is the trunk bundle
        # dipping to reach an internal join or the exit, and keeps the midpoint
        # diagonal so it does not read as a mid-section merge.
        if not is_exit_port or _has_in_section_predecessor(
            ctx.graph, edge.source, sec_id
        ):
            return False
    return True


def _bypass_v_is_one_way_step(graph: MetroGraph, v_id: str) -> bool:
    """True when a bypass V's predecessor and successor sit on different rows.

    A one-way step (the bypassed lines leave one row and land on another) has a
    single descending diagonal with no symmetric return leg.  A symmetric bypass
    loop (predecessor and successor on the same row, the V dipping away and back)
    returns False: its two legs mirror each other, so widening them by whatever
    horizontal room each leg happens to have would leave the loop lopsided.
    """
    preds = [
        graph.stations[e.source].y
        for e in graph.edges_to(v_id)
        if e.source in graph.stations
    ]
    succs = [
        graph.stations[e.target].y
        for e in graph.edges_from(v_id)
        if e.target in graph.stations
    ]
    if not preds or not succs:
        return False
    return abs(min(preds) - min(succs)) > COORD_TOLERANCE


def _has_in_section_predecessor(
    graph: MetroGraph, station_id: str, section_id: str
) -> bool:
    """Whether any edge into *station_id* starts at a non-port station in the
    same section (as opposed to the section boundary: an entry port or an
    inter-section feed)."""
    for e in graph.edges_to(station_id):
        pred = graph.stations.get(e.source)
        if pred is not None and not pred.is_port and pred.section_id == section_id:
            return True
    return False


def prefers_join_bias(ctx: _RoutingCtx, edge: Edge) -> bool:
    """Whether an edge that both forks and joins should seat at its join end.

    Each bias exists to make a fan read as a fan at the end it belongs to, so
    when both apply the wider fan wins: a six-way convergence dominates the
    two-way split its source happens to also make, and biasing to that split
    instead seats the convergence off the source's own label rather than off the
    hub the branches meet at.  An equal-degree pair keeps the fork bias, which
    puts a plain diamond's transitions at its narrow ends.

    A port target is excluded whatever its in-degree: it collects everything
    leaving the section rather than gathering a fan, and a line changing row
    before the boundary needs its transition early, taken while the row it
    departs is clear of the stations further along it.
    """
    if ctx.graph.stations[edge.target].is_port:
        return False
    fork_degree = len(ctx.fork_targets.get(edge.source, ()))
    join_degree = len(ctx.join_sources.get(edge.target, ()))
    return join_degree > fork_degree


def _fan_plan_seats_the_fork(ctx: _RoutingCtx, fork_id: str) -> bool:
    """Whether a live fan plan states the lanes the legs of *fork_id* open into."""
    execution = ctx.graph.fan_plan_execution
    return execution is not None and any(
        plan.fork_station_id == fork_id and plan.legacy_reason is None
        for plan in execution.plans
    )


def _fused_opening_legs(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> int:
    """How many legs of a planned fan open beyond *edge* on a heading it fuses with.

    Legs peeling off one fork toward the same side turn at one column, so they
    leave it as rays from a single point: by the end of their corner curves two
    of them stand ``curve_radius * sin(heading difference)`` apart, which is
    under a bundle step wherever the headings are close and draws the pair as one
    stroke for the length of the opening.  Counting the legs a leg fuses with
    lets the deepest peel first and holds each shallower one back a step, so the
    openings nest in the order the fan seats them rather than stacking on one
    point.

    A port fork is excluded: it is the boundary a section's trunk arrives at
    rather than a station a fan opens from, and the entry machinery seats the
    spread of the legs it feeds.
    """
    drop = tgt.y - src.y
    if abs(drop) <= COORD_TOLERANCE_FINE or edge.source not in ctx.fork_stations:
        return 0
    if src.is_port or not _fan_plan_seats_the_fork(ctx, edge.source):
        return 0
    heading = math.atan2(abs(drop), ctx.diagonal_run)
    fused = 0
    for sibling_id in ctx.fork_targets.get(edge.source, ()):
        sibling = ctx.graph.stations.get(sibling_id)
        if sibling is None:
            continue
        sibling_drop = sibling.y - src.y
        if (
            sibling_drop * drop <= 0.0
            or abs(sibling_drop) <= abs(drop) + COORD_TOLERANCE_FINE
        ):
            continue
        sibling_heading = math.atan2(abs(sibling_drop), ctx.diagonal_run)
        if ctx.curve_radius * math.sin(sibling_heading - heading) < ctx.offset_step:
            fused += 1
    return fused


def _route_diagonal(
    edge: Edge, src: Station, tgt: Station, ctx: _RoutingCtx
) -> RoutedPath:
    """Route with horizontal runs and a 45-degree diagonal transition."""
    sx, sy = src.x, src.y
    tx, ty = tgt.x, tgt.y
    dx = tx - sx

    # Minimum straight track at endpoints
    if src.is_port or tgt.is_port:
        min_straight = ctx.curve_radius + MIN_STRAIGHT_PORT
    else:
        min_straight = MIN_STRAIGHT_EDGE

    # Extend straight run past labels at fork/join stations, but only
    # when there is enough horizontal room.  If label clearance would
    # collapse the diagonal to a near-vertical line, fall back to the
    # base min_straight so a proper diagonal can still be drawn.
    src_min = min_straight
    tgt_min = min_straight
    if edge.source in ctx.fork_stations and src.label.strip():
        src_min = max(min_straight, label_text_width(src.label) / 2)
    if edge.target in ctx.join_stations and tgt.label.strip():
        tgt_min = max(min_straight, label_text_width(tgt.label) / 2)
    # File-input stations fan out to several downstream stations; the
    # diagonal should start past the icon so the line visually leaves
    # the file before forking.  Without this clamp the diagonal can
    # start inside the icon's drawn area (MIN_STRAIGHT_EDGE = 10 px,
    # icon extends to ~station.x + 20 + 14).
    if src.is_terminus and edge.source in ctx.fork_stations:
        src_min = max(src_min, ICON_TERMINUS_FORK_LEAD)
    if tgt.is_terminus and edge.target in ctx.join_stations:
        tgt_min = max(tgt_min, ICON_TERMINUS_FORK_LEAD)
    # A downward off-track output normally drops on the same side as its
    # producer's name label, so the descent turns down past the label's far edge
    # to stay clear of the text.  When producer and output are both fanned branch
    # stations (a symmetric fork's dead-end output, half-grid on the outer side),
    # the producer's label sits on the opposite (trunk) side instead, so the drop
    # runs clear without the clearance -- forcing it would collapse the diagonal
    # into a banned right angle.
    co_fanned = (
        edge.source in ctx.graph.half_grid_station_ids
        and edge.target in ctx.graph.half_grid_station_ids
    )
    drop_label_clearance = 0.0
    if (
        tgt.off_track
        and ty > sy + COORD_TOLERANCE_FINE
        and src.label.strip()
        and not co_fanned
    ):
        drop_label_clearance = label_text_width(src.label) / 2 + LABEL_BBOX_MARGIN
        src_min = max(src_min, drop_label_clearance)
    peel_delay = _fused_opening_legs(edge, src, tgt, ctx) * ctx.offset_step
    if src_min + peel_delay + tgt_min + ctx.diagonal_run <= abs(dx):
        src_min += peel_delay
    if src_min + tgt_min + ctx.diagonal_run > abs(dx):
        src_min = max(min_straight, drop_label_clearance)
        tgt_min = min_straight

    # Side-branch ascents: override the fork bias so the diagonal lands
    # near the target.  The side-branch line then stays on its own track
    # from the source until the section boundary, instead of merging
    # with the main trunk bundle mid-section.
    is_side_branch = _is_side_branch_ascent(edge, src, tgt, ctx)
    is_fork_flag = edge.source in ctx.fork_stations and not is_side_branch
    is_join_flag = edge.target in ctx.join_stations or is_side_branch
    if is_fork_flag and is_join_flag and prefers_join_bias(ctx, edge):
        is_fork_flag = False

    # Bypass-V edges: bias the diagonal toward V on both halves with
    # equal V-side flat reservations so V sits at the centre of the
    # straight segment of the bypass loop.
    v_flat_half = CURVE_RADIUS + MIN_STATION_FLAT_LENGTH / 2
    diagonal_run = ctx.diagonal_run
    tgt_is_bypass_v = tgt.is_hidden and is_bypass_v(edge.target)
    src_is_bypass_v = src.is_hidden and is_bypass_v(edge.source)
    is_bypass_edge = tgt_is_bypass_v or src_is_bypass_v
    if tgt_is_bypass_v:
        is_fork_flag = False
        is_join_flag = True
        tgt_min = v_flat_half
        if src_min + tgt_min + diagonal_run > abs(dx):
            tgt_min = MIN_STRAIGHT_EDGE
    elif src_is_bypass_v:
        is_fork_flag = True
        is_join_flag = False
        src_min = v_flat_half
        if src_min + tgt_min + diagonal_run > abs(dx):
            src_min = MIN_STRAIGHT_EDGE

    # A steep multi-line bypass bundle descending past an in-line terminal is
    # squeezed through the narrow channel between that terminal's name label and
    # the source station's, and a near-vertical descent there fails two ways at
    # once: its vertically-offset lines separate by only OFFSET_STEP * cos(theta),
    # fusing below the channel floor, and the steep diagonal rakes the source
    # label.  A gentler diagonal clears both, so flatten toward 45 degrees
    # (diagonal run >= vertical drop) within the room the endpoint straights
    # leave.  Scoped to a one-way-step bypass V: a symmetric bypass loop threads
    # the same descent as two mirrored legs whose spread stagger already
    # separates them, and widening those legs by whatever room each happens to
    # have would leave the loop lopsided, so it keeps its shared run.
    drop = abs(ty - sy)
    v_id = edge.target if tgt_is_bypass_v else edge.source if src_is_bypass_v else None
    if (
        is_bypass_edge
        and drop > diagonal_run
        and v_id is not None
        and _bypass_v_is_one_way_step(ctx.graph, v_id)
    ):
        _, line_ids, _ = gather_member_edges(ctx.graph, edge)
        if len(line_ids) > 1:
            room = abs(dx) - src_min - tgt_min
            diagonal_run = max(diagonal_run, min(drop, room))

    # An off-track output whose producer carries a strike-clearance lead lever
    # seats its divergence at the layout's reserved lead (icon offset minus the
    # diagonal and the uniform tail), so the flat tail into the icon stays
    # ``OFF_TRACK_OUTPUT_TAIL`` for every output while the divergence moves past
    # the producer's name.  Scoped to a grown lever so no other output's
    # divergence model changes.
    section = ctx.graph.sections.get(src.section_id or "")
    if (
        tgt.off_track
        and section is not None
        and section.off_track_lead_extra.get(edge.source, 0)
        and not is_bypass_edge
    ):
        src_min = max(min_straight, abs(dx) - diagonal_run - OFF_TRACK_OUTPUT_TAIL)
        is_fork_flag = True
        is_join_flag = False

    diag_start_x, diag_end_x = _compute_diagonal_placement(
        sx,
        tx,
        diagonal_run,
        src_min,
        tgt_min,
        is_fork_flag,
        is_join_flag,
    )

    direction = section.direction if section else "LR"
    return RoutedPath(
        edge=edge,
        line_id=edge.line_id,
        points=diagonal_centreline(
            direction, (sx, sy), (tx, ty), diag_start_x, diag_end_x
        ),
    )
