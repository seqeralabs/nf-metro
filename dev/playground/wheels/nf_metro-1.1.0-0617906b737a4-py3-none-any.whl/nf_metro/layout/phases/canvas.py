"""Whole-graph canvas translation into view and section renumbering by reading order."""

from __future__ import annotations

from nf_metro.layout.constants import (
    TITLE_BAND_CLEARANCE,
    TITLE_BAND_OVERLAP_FLOOR,
)
from nf_metro.layout.phases.bbox import (
    _min_drawn_section_bbox_top,
    _min_section_bbox_top,
)
from nf_metro.parser.model import MetroGraph, Section


def _renumber_sections_by_grid(graph: MetroGraph) -> None:
    """Renumber sections by visual reading order.

    Groups sections into flow sweeps separated by fold boundaries:
    each left-to-right (or right-to-left) run is one sweep, with
    TB fold sections belonging to the sweep they terminate.  Within
    each sweep, sections are numbered by (grid_col, grid_row) so
    columns go left-to-right and stacked sections go top-to-bottom.
    All numbers in sweep N+1 are greater than those in sweep N.
    """
    from collections import deque

    import networkx as nx

    dag: nx.DiGraph[str] = nx.DiGraph()
    for sid in graph.sections:
        dag.add_node(sid)
    if graph.section_dag:
        for src, tgt in graph.section_dag.section_edges:
            if src in graph.sections and tgt in graph.sections:
                dag.add_edge(src, tgt)

    secs = graph.sections

    def _is_direction_change(src: str, tgt: str) -> bool:
        """True when flow direction reverses between two sections."""
        sd, td = secs[src].direction, secs[tgt].direction
        # TB->LR/RL: only counts if the TB's predecessors flowed
        # the opposite way (i.e. TB is a fold boundary).
        if sd == "TB" and td in ("LR", "RL"):
            for pred in dag.predecessors(src):
                pd = secs[pred].direction
                if pd in ("LR", "RL") and pd != td:
                    return True
            return False
        if sd in ("LR", "RL") and td in ("LR", "RL") and sd != td:
            return True
        return False

    sweep: dict[str, int] = {}
    roots = [n for n in dag.nodes() if dag.in_degree(n) == 0]
    q: deque[str] = deque()
    for r in roots:
        sweep[r] = 0
        q.append(r)

    while q:
        node = q.popleft()
        for succ in dag.successors(node):
            new_depth = sweep[node]
            if _is_direction_change(node, succ):
                new_depth = sweep[node] + 1
            if succ not in sweep or new_depth < sweep[succ]:
                sweep[succ] = new_depth
                q.append(succ)

    for sid in graph.sections:
        if sid not in sweep:
            sweep[sid] = 0

    # Disconnected components: number each flow fully before the next,
    # ordered by the topmost grid_row so top flows come first.
    from nf_metro.layout.section_placement import _weakly_connected_components

    section_edges = graph.section_dag.section_edges if graph.section_dag else set()
    comp_idx: dict[str, int] = {}
    for rank, comp in enumerate(
        sorted(
            _weakly_connected_components(graph, section_edges),
            key=lambda c: min(graph.sections[sid].grid_row for sid in c),
        )
    ):
        for sid in comp:
            comp_idx[sid] = rank

    # Determine flow direction for each sweep: RL sweeps number
    # columns right-to-left (descending grid_col) to match the flow.
    sweep_is_rl: dict[int, bool] = {}
    for sid, s in graph.sections.items():
        sw = sweep[sid]
        if sw not in sweep_is_rl and s.direction == "RL":
            sweep_is_rl[sw] = True
        elif sw not in sweep_is_rl and s.direction == "LR":
            sweep_is_rl[sw] = False

    def _sort_key(s: Section) -> tuple[int, int, int, int]:
        sw = sweep[s.id]
        col = -s.grid_col if sweep_is_rl.get(sw, False) else s.grid_col
        return (comp_idx.get(s.id, 0), sw, col, s.grid_row)

    sorted_sections = sorted(graph.sections.values(), key=_sort_key)
    for i, section in enumerate(sorted_sections, start=1):
        section.number = i


def _translate_graph_y(graph: MetroGraph, shift: float) -> None:
    """Shift every station, section bbox, and port down by ``shift``."""
    for st in graph.stations.values():
        st.y += shift
    for section in graph.sections.values():
        section.bbox_y += shift
    for port in graph.ports.values():
        port.y += shift


def _canvas_top_shortfall(graph: MetroGraph, section_y_padding: float) -> float:
    """Downward shift needed so the graph clears both top floors (0 if none).

    Containment: every section must sit ``section_y_padding`` below the canvas
    top.  Title: when the map is titled *and* ``graph.reserve_title_band`` (set
    by :func:`~nf_metro.api.prepare_graph` -- false for ``--bare`` or a logo
    folded into the legend, cases where render draws nothing up there), a
    *drawn* section whose header badge overlaps the title band (box top above
    ``TITLE_BAND_OVERLAP_FLOOR``) is lifted clear to ``TITLE_BAND_CLEARANCE``
    -- a map already clearing the title, and implicit holders (which draw no
    badge), are left untouched.
    """
    min_all = _min_section_bbox_top(graph, section_y_padding)
    shortfall = max(0.0, section_y_padding - min_all)
    if graph.title and graph.reserve_title_band:
        min_drawn = _min_drawn_section_bbox_top(graph)
        if min_drawn is not None and min_drawn < TITLE_BAND_OVERLAP_FLOOR:
            shortfall = max(shortfall, TITLE_BAND_CLEARANCE - min_drawn)
    return shortfall


def _canvas_top_preserved(
    graph: MetroGraph, section_y_padding: float, shift: float
) -> bool:
    """True if ``shift`` keeps every section within its top floor.

    The containment floor (``section_y_padding``) bounds all sections; the
    no-overlap floor (``TITLE_BAND_OVERLAP_FLOOR``) bounds drawn sections on a
    titled map whose title band will actually be drawn (see
    ``graph.reserve_title_band``).  Lets the grid snap reject a candidate that
    would lift the top above a floor.
    """
    min_all = _min_section_bbox_top(graph, section_y_padding)
    if min_all + shift < section_y_padding - 1e-6:
        return False
    if graph.title and graph.reserve_title_band:
        min_drawn = _min_drawn_section_bbox_top(graph)
        if (
            min_drawn is not None
            and min_drawn + shift < TITLE_BAND_OVERLAP_FLOOR - 1e-6
        ):
            return False
    return True


def _shift_graph_into_canvas(graph: MetroGraph, section_y_padding: float) -> None:
    """Shift the whole graph down if the topmost section is above the canvas.

    Lifts the graph by ``_canvas_top_shortfall`` so it clears the canvas-top
    margin and, on a titled map, the title band.  No-op when it already does.
    """
    shortfall = _canvas_top_shortfall(graph, section_y_padding)
    if shortfall > 0:
        _translate_graph_y(graph, shortfall)
