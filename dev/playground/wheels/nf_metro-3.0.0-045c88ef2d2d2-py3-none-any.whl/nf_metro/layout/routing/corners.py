"""Concentric corner geometry for bundled metro lines.

When multiple metro lines travel as a parallel bundle and turn a corner,
each line follows a different-radius arc to maintain the bundle's visual
ordering without crossings.  Lines on the OUTSIDE of the turn get larger
radii (wider arcs), lines on the INSIDE get smaller radii (tighter arcs).

Key invariant
-------------
A line on the left of a downward-going bundle must be on TOP of the
following horizontal if the bundle turns left, but on the BOTTOM if it
turns right.  Equivalently, the line on the outside of every corner
always gets the largest radius.

All radii are computed as::

    radius = base_radius + k * offset_step

where *k* ranges from 0 (innermost) to n-1 (outermost).  The radius
is NEVER variable beyond the line's position within the bundle.
"""

from __future__ import annotations

import math
from collections.abc import Iterable
from typing import NamedTuple

from nf_metro.layout.constants import (
    COORD_TOLERANCE,
    COORD_TOLERANCE_FINE,
    OFFSET_STEP,
)
from nf_metro.layout.pass_metrics import active_curve_radius
from nf_metro.layout.routing.common import Direction, bundle_width

# ---------------------------------------------------------------------------
# Primitive: reversed (inner/outer) offset
# ---------------------------------------------------------------------------


def wholesale_corner_translation(
    point_a: tuple[float, float],
    point_b: tuple[float, float],
    incoming: tuple[float, float],
    outgoing: tuple[float, float],
    tolerance: float = COORD_TOLERANCE,
) -> bool:
    """Whether two matching corners translate both flanking legs equally."""
    delta_x = point_b[0] - point_a[0]
    delta_y = point_b[1] - point_a[1]
    tangent_shift = abs(
        delta_x * (incoming[0] + outgoing[0]) + delta_y * (incoming[1] + outgoing[1])
    )
    incoming_leg_offset = abs(delta_x * outgoing[0] + delta_y * outgoing[1])
    outgoing_leg_offset = abs(delta_x * incoming[0] + delta_y * incoming[1])
    return (
        tangent_shift <= tolerance
        and max(incoming_leg_offset, outgoing_leg_offset) > tolerance
        and abs(incoming_leg_offset - outgoing_leg_offset) <= tolerance
    )


def resolve_curve_radius_at(
    points: list[tuple[float, float]],
    desired_radii: list[float] | None,
    corner_idx: int,
    default_radius: float | None = None,
) -> float:
    """Resolve one corner radius from its adjacent segment budgets.

    ``corner_idx`` indexes the interior waypoints, so zero refers to
    ``points[1]``.  The allocation matches :func:`resolve_curve_radii` exactly,
    including the proportional budget shared by neighbouring corners.
    """
    if default_radius is None:
        default_radius = active_curve_radius()
    n_corners = len(points) - 2
    if corner_idx < 0 or corner_idx >= n_corners:
        raise IndexError("corner index out of range")

    i = corner_idx + 1
    desired_r = (
        desired_radii[corner_idx]
        if desired_radii and corner_idx < len(desired_radii)
        else default_radius
    )

    prev, curr, nxt = points[i - 1], points[i], points[i + 1]
    len1 = math.hypot(curr[0] - prev[0], curr[1] - prev[1])
    len2 = math.hypot(nxt[0] - curr[0], nxt[1] - curr[1])

    if i > 1:
        prev_r = (
            desired_radii[i - 2]
            if desired_radii and (i - 2) < len(desired_radii)
            else default_radius
        )
        total = prev_r + desired_r
        max_len1 = len1 * desired_r / total if total > 0 else len1 / 2
    else:
        max_len1 = len1

    if i < len(points) - 2:
        next_r = (
            desired_radii[i]
            if desired_radii and i < len(desired_radii)
            else default_radius
        )
        total = desired_r + next_r
        max_len2 = len2 * desired_r / total if total > 0 else len2 / 2
    else:
        max_len2 = len2

    return min(desired_r, max_len1, max_len2)


def corner_radius_budget(
    points: list[tuple[float, float]], desired_radii: list[float], corner_idx: int
) -> float:
    """The largest radius corner *corner_idx* can take that
    :func:`resolve_curve_radius_at` leaves unclamped, its neighbours keeping
    their *desired_radii*: each leg's length less the neighbouring corner's
    share of it, or the whole leg at either end of the route."""
    i = corner_idx + 1
    len_in = math.dist(points[i - 1], points[i])
    len_out = math.dist(points[i], points[i + 1])
    prev_r = desired_radii[corner_idx - 1] if corner_idx > 0 else 0.0
    next_r = desired_radii[corner_idx + 1] if i < len(points) - 2 else 0.0
    return min(len_in - prev_r, len_out - next_r)


def padded_curve_radii(
    points: list[tuple[float, float]],
    curve_radii: Iterable[float] | None,
    base_radius: float | None = None,
) -> list[float]:
    """*curve_radii* for every corner of *points*, *base_radius* standing in
    for any it lacks."""
    if base_radius is None:
        base_radius = active_curve_radius()
    radii = list(curve_radii or [])
    return radii + [base_radius] * (len(points) - 2 - len(radii))


def largest_concentric_reference(
    ceiling: float, lanes: Iterable[tuple[float, float]]
) -> float | None:
    """The largest reference radius, up to *ceiling*, that every lane fits.

    Each lane is ``(budget, shift)``: it draws at the reference plus *shift*,
    which must stay within its :func:`corner_radius_budget`. ``None`` when the
    largest such reference would leave some lane's radius under
    :data:`COORD_TOLERANCE_FINE`.
    """
    cap = math.inf
    floor = -math.inf
    for budget, shift in lanes:
        cap = min(cap, budget - shift)
        floor = max(floor, COORD_TOLERANCE_FINE - shift)
    reference = min(ceiling, cap)
    return None if reference < floor else reference


def resolve_curve_radii(
    points: list[tuple[float, float]],
    desired_radii: list[float] | None,
    default_radius: float | None = None,
) -> list[float]:
    """Compute effective curve radii after segment-budget clamping.

    For each corner (intermediate waypoint), the desired radius is clamped
    to the available segment length on each side.  When adjacent corners
    share a segment, space is allocated proportionally based on their
    desired radii so concentric geometry is preserved.

    This is the single source of truth for radius resolution, used by both
    the routing layer (for validation) and the rendering layer (for SVG
    path construction).

    Parameters
    ----------
    points : list of (x, y) tuples
        The waypoints of the routed path.
    desired_radii : list of float or None
        Desired radius at each corner (length must equal ``len(points) - 2``
        when not None).  Falls back to *default_radius* for missing entries.
    default_radius : float
        Fallback radius when *desired_radii* is None or too short.

    Returns
    -------
    list of float
        Effective (clamped) radius for each corner.
    """
    if default_radius is None:
        default_radius = active_curve_radius()
    n_corners = len(points) - 2
    if n_corners <= 0:
        return []

    return [
        resolve_curve_radius_at(
            points,
            desired_radii,
            corner_idx,
            default_radius=default_radius,
        )
        for corner_idx in range(n_corners)
    ]


def desired_curve_radii(
    points: list[tuple[float, float]],
    default_radius: float,
) -> list[float]:
    """The radius each interior vertex of *points* asks for.

    A vertex whose flanking legs continue in the same direction is not a
    direction change and asks for no curve; every other interior vertex asks
    for *default_radius*.  Feed the result to :func:`resolve_curve_radii` to
    clamp it to the segment budgets.

    Straightness is measured as the outgoing leg's perpendicular distance
    from the incoming leg's line, so the :data:`COORD_TOLERANCE_FINE` band
    means the same deviation on a short leg as on a long one.
    """
    desired: list[float] = []
    for index in range(1, len(points) - 1):
        incoming = (
            points[index][0] - points[index - 1][0],
            points[index][1] - points[index - 1][1],
        )
        outgoing = (
            points[index + 1][0] - points[index][0],
            points[index + 1][1] - points[index][1],
        )
        cross = incoming[0] * outgoing[1] - incoming[1] * outgoing[0]
        dot = incoming[0] * outgoing[0] + incoming[1] * outgoing[1]
        incoming_length = math.hypot(incoming[0], incoming[1])
        straight_through = (
            dot > 0.0
            and incoming_length > 0.0
            and abs(cross) / incoming_length <= COORD_TOLERANCE_FINE
        )
        desired.append(0.0 if straight_through else default_radius)
    return desired


class CornerTangent(NamedTuple):
    """Rounded-corner tangent points for one interior vertex.

    ``before``/``after`` are where the smoothing curve leaves the incoming
    leg and rejoins the outgoing leg; ``corner`` is the vertex the curve
    bends around.  ``curved`` is False for a degenerate vertex (a
    zero-length neighbouring leg), where all three points collapse to the
    vertex itself and no curve is drawn.
    """

    curved: bool
    before: tuple[float, float]
    corner: tuple[float, float]
    after: tuple[float, float]


def curve_tangents(
    points: list[tuple[float, float]],
    resolved: list[float],
) -> list[CornerTangent]:
    """Per-interior-vertex rounded-corner tangent points.

    For each interior vertex ``i`` (``1..len(points)-2``) the smoothing
    curve leaves the incoming leg at ``before`` and rejoins the outgoing leg
    at ``after``, each a distance ``resolved[i-1]`` from the corner along the
    respective unit leg vector.

    This is the single source of tangent geometry shared by the static SVG
    renderer and the animation renderer, so a corner is rounded identically
    in both.  ``resolved`` is the clamped radius list from
    :func:`resolve_curve_radii` (length ``len(points) - 2``).
    """
    tangents: list[CornerTangent] = []
    for i in range(1, len(points) - 1):
        prev, curr, nxt = points[i - 1], points[i], points[i + 1]
        dx1, dy1 = curr[0] - prev[0], curr[1] - prev[1]
        len1 = (dx1**2 + dy1**2) ** 0.5
        dx2, dy2 = nxt[0] - curr[0], nxt[1] - curr[1]
        len2 = (dx2**2 + dy2**2) ** 0.5
        r = resolved[i - 1]
        if len1 > 0 and len2 > 0:
            before = (curr[0] - dx1 / len1 * r, curr[1] - dy1 / len1 * r)
            after = (curr[0] + dx2 / len2 * r, curr[1] + dy2 / len2 * r)
            tangents.append(CornerTangent(True, before, curr, after))
        else:
            tangents.append(CornerTangent(False, curr, curr, curr))
    return tangents


def corner_arc_controls(
    before: tuple[float, float],
    corner: tuple[float, float],
    after: tuple[float, float],
) -> tuple[tuple[float, float], tuple[float, float]]:
    """Cubic control points that draw a rounded corner as a circular arc.

    The arc leaves the incoming leg at *before* and rejoins the outgoing leg at
    *after*, both a tangent arm from *corner*. A circular arc of deflection
    ``phi`` drawn as one cubic puts each control point ``4/3 * tan(phi / 4)``
    radii along its tangent, which is ``k = 4/3 * tan(phi / 4) / tan(phi / 2)``
    of the tangent arm; the radial error is under 0.03% of the radius up to a
    right angle, so concentric lanes drawn this way stay parallel through the
    turn. With ``t = tan(phi / 4)`` the ratio is ``2/3 * (1 - t**2)``, so a
    straight-through corner gets 2/3. A corner with a zero arm is a straight
    run between its tangent points.
    """
    d_in = (corner[0] - before[0], corner[1] - before[1])
    d_out = (after[0] - corner[0], after[1] - corner[1])
    len_in = math.hypot(*d_in)
    len_out = math.hypot(*d_out)
    if len_in <= 0.0 or len_out <= 0.0:
        return before, after
    cos_phi = (d_in[0] * d_out[0] + d_in[1] * d_out[1]) / (len_in * len_out)
    t = math.tan(math.acos(max(-1.0, min(1.0, cos_phi))) / 4)
    k = 2.0 / 3.0 * (1.0 - t * t)
    return (
        (before[0] + d_in[0] * k, before[1] + d_in[1] * k),
        (after[0] - d_out[0] * k, after[1] - d_out[1] * k),
    )


def cubic_point(
    a: tuple[float, float],
    c1: tuple[float, float],
    c2: tuple[float, float],
    b: tuple[float, float],
    t: float,
) -> tuple[float, float]:
    """The point at *t* on the cubic Bezier from *a* to *b* with handles *c1*, *c2*."""
    s = 1.0 - t
    return (
        s**3 * a[0] + 3 * s * s * t * c1[0] + 3 * s * t * t * c2[0] + t**3 * b[0],
        s**3 * a[1] + 3 * s * s * t * c1[1] + 3 * s * t * t * c2[1] + t**3 * b[1],
    )


def cubic_tangent(
    a: tuple[float, float],
    c1: tuple[float, float],
    c2: tuple[float, float],
    b: tuple[float, float],
    t: float,
) -> tuple[float, float]:
    """The (unnormalised) forward tangent at *t* of :func:`cubic_point`'s cubic."""
    s = 1.0 - t
    return (
        s * s * (c1[0] - a[0]) + 2 * s * t * (c2[0] - c1[0]) + t * t * (b[0] - c2[0]),
        s * s * (c1[1] - a[1]) + 2 * s * t * (c2[1] - c1[1]) + t * t * (b[1] - c2[1]),
    )


def flatten_cubic(
    a: tuple[float, float],
    c1: tuple[float, float],
    c2: tuple[float, float],
    b: tuple[float, float],
    steps: int,
) -> list[tuple[float, float]]:
    """The *steps* points at ``k / steps`` (``k = 1 .. steps``) along the cubic
    :func:`cubic_point` draws, ending on *b*."""
    return [cubic_point(a, c1, c2, b, k / steps) for k in range(1, steps + 1)]


def corner_from_arc(
    before: tuple[float, float],
    c1: tuple[float, float],
    c2: tuple[float, float],
    after: tuple[float, float],
) -> tuple[float, float]:
    """The corner vertex a drawn arc was built around.

    Both handles sit the same fraction ``k`` of their leg from the tangent
    points, so together they span ``k`` of the chord; dividing the first
    handle's offset by ``k`` recovers the vertex, a straight-through corner
    included. A zero-arm corner has no handle offset and is drawn straight, so
    it folds to *before*.
    """
    d1 = (c1[0] - before[0], c1[1] - before[1])
    chord = (after[0] - before[0], after[1] - before[1])
    span = (d1[0] + after[0] - c2[0], d1[1] + after[1] - c2[1])
    scale = (chord[0] * chord[0] + chord[1] * chord[1]) / max(
        span[0] * chord[0] + span[1] * chord[1], 1e-12
    )
    return (before[0] + d1[0] * scale, before[1] + d1[1] * scale)


def reversed_offset(offset: float, max_offset: float) -> float:
    """Flip a line's offset within a bundle.

    Maps the outermost line (offset == max_offset) to 0 and the
    innermost line (offset == 0) to max_offset.  Used whenever a
    concentric corner swaps the spatial ordering of lines in a bundle.
    """
    return max_offset - offset


def corner_radius(
    offset: float,
    max_offset: float,
    *,
    outside: bool,
    base_radius: float,
) -> float:
    """Compute the concentric arc radius for one line at a corner.

    Every concentric corner radius in the system follows::

        radius = base_radius + effective_offset

    where *effective_offset* is either the raw offset (line is on the
    outside of the turn) or the reversed offset (line is on the inside).

    Parameters
    ----------
    offset : float
        This line's offset within the bundle (0 to *max_offset*).
    max_offset : float
        Maximum offset across all lines in the bundle.
    outside : bool
        ``True`` when the line at *offset* is on the **outside** of the
        turn and therefore needs the larger radius.  ``False`` when it
        is on the inside.
    base_radius : float
        Minimum curve radius (innermost line).

    Returns
    -------
    float
        ``base_radius + offset`` when *outside* is True,
        ``base_radius + (max_offset - offset)`` when False.
    """
    eff = offset if outside else reversed_offset(offset, max_offset)
    return reference_anchored_radius(eff, base_radius)


def concentric_corner_radius(
    turn_in: tuple[float, float],
    turn_out: tuple[float, float],
    dx: float,
    base_radius: float,
    *,
    min_radius: float | None = None,
) -> float:
    """Concentric arc radius for one line of a wholesale-translated 90° corner.

    When a bundle of parallel lines turns a 90° corner and the *entire* corner
    is translated per line so this line's vertical leg sits *dx* to the side of
    the reference line, the arcs share a common centre iff::

        radius = base_radius - dx * (turn_out_x - turn_in_x)

    (derived by equating every line's arc centre ``corner + radius *
    (turn_out - turn_in)``; ``turn_out_x - turn_in_x`` is always +/-1 for a real
    90° turn, and a valid bundle must fan in X since a pure-Y translation would
    overlap the vertical legs - so the X displacement alone fixes the radius).
    This is the single direction-driven entry point for nestable corners: any
    orientation - right-then-down, down-then-left, etc. - is mapped to the
    correct signed offset purely from the two travel vectors, so the same
    routine sizes every such corner regardless of compass direction.

    The arcs are genuinely concentric only when the *whole* corner translates
    together.  At a *transition* corner - one flanking leg fanned by *dx*, the
    other pinned at a fixed (e.g. port) offset - this still returns a sensibly
    nested radius (sized to the fanned leg) but the arcs do not share a centre.

    Parameters
    ----------
    turn_in, turn_out : tuple of float
        Unit travel-direction vectors into and out of the corner (axis-aligned;
        ``turn_out - turn_in`` has both components +/-1 for a real 90° turn).
    dx : float
        This line's signed X displacement from the bundle's reference line.
    base_radius : float
        Reference-line radius.
    min_radius : float or None
        Optional floor (see :func:`reference_anchored_radius`); inside-of-turn
        lines fall below *base_radius* and a deep bundle can drive it to zero.

    Returns
    -------
    float
        The concentric radius via :func:`reference_anchored_radius`.
    """
    ux = turn_out[0] - turn_in[0]
    return reference_anchored_radius(-dx * ux, base_radius, min_radius=min_radius)


def _corner_travel_units(
    prev: tuple[float, float],
    corner: tuple[float, float],
    nxt: tuple[float, float],
) -> tuple[tuple[float, float], tuple[float, float]]:
    """Axis-aligned unit travel vectors into and out of an axis-aligned corner.

    Each leg snaps to its dominant axis, so a segment carrying sub-pixel
    off-axis drift resolves to a clean cardinal unit.
    """

    def unit(a: tuple[float, float], b: tuple[float, float]) -> tuple[float, float]:
        sx, sy = b[0] - a[0], b[1] - a[1]
        if abs(sx) >= abs(sy):
            return (math.copysign(1.0, sx) if sx else 0.0, 0.0)
        return (0.0, math.copysign(1.0, sy) if sy else 0.0)

    return unit(prev, corner), unit(corner, nxt)


def concentric_corner_radius_at(
    prev: tuple[float, float],
    corner: tuple[float, float],
    nxt: tuple[float, float],
    dx: float,
    base_radius: float,
    *,
    min_radius: float | None = None,
) -> float:
    """Concentric radius for one bundle line, deriving the turn from the points.

    Geometry-keyed entry point for a wholesale-translated 90° corner: it reads
    the two travel vectors from the corner's own three waypoints (*prev* ->
    *corner* -> *nxt*) and forwards them to :func:`concentric_corner_radius`, so
    a caller supplies only the corner geometry and this line's signed
    displacement *dx* from the bundle reference - never a hand-picked sign.  Use
    this at every wholesale-translated bundle corner; reserve raw
    :func:`reference_anchored_radius` for transition corners (one leg pinned,
    e.g. a converging port jog) where non-concentric is intended.
    """
    turn_in, turn_out = _corner_travel_units(prev, corner, nxt)
    return concentric_corner_radius(
        turn_in, turn_out, dx, base_radius, min_radius=min_radius
    )


def turn_shift(
    prev: tuple[float, float],
    corner: tuple[float, float],
    nxt: tuple[float, float],
    displacement: tuple[float, float],
) -> float:
    """How much longer a line's tangent arm is than the reference line's for
    the two to turn about one centre at a turn of any angle.

    The generalisation of :func:`concentric_corner_radius` beyond 90 degrees.
    A corner's radius here is its tangent arm, the distance from the vertex to
    where the curve leaves each leg; for a circular turn of deflection ``phi``
    that is ``R * tan(phi / 2)``. When a bundle turns wholesale, each line's
    vertex sits on the turn's bisector, *displacement* from the reference
    line's vertex, and the lines share a centre iff::

        arm = reference_arm + displacement . (u_in - u_out) / 2

    where ``u_in`` and ``u_out`` are the unit travel vectors into and out of
    the corner (read from the line's own *prev* -> *corner* -> *nxt*, which
    must both have length). The shift is positive for a line on the outside of
    the turn. At 90 degrees this is the ``-dx * ux`` rule
    :func:`concentric_corner_radius` applies.
    """
    in_len = math.dist(prev, corner)
    out_len = math.dist(corner, nxt)
    u_in = ((corner[0] - prev[0]) / in_len, (corner[1] - prev[1]) / in_len)
    u_out = ((nxt[0] - corner[0]) / out_len, (nxt[1] - corner[1]) / out_len)
    return (
        displacement[0] * (u_in[0] - u_out[0]) + displacement[1] * (u_in[1] - u_out[1])
    ) / 2


def concentric_reference_radius_at(
    prev: tuple[float, float],
    corner: tuple[float, float],
    nxt: tuple[float, float],
    dx: float,
    lane_radius: float,
) -> float:
    """Reference radius that gives one displaced lane *lane_radius*.

    This is the inverse of :func:`concentric_corner_radius_at` for a single
    lane.  A caller choosing one reference for a corner family takes the
    maximum result across its lanes, then derives every lane radius through
    :func:`concentric_corner_radius_at`.  Keeping both directions here gives
    routing code one source of truth for the turn-dependent offset sign.
    """
    turn_in, turn_out = _corner_travel_units(prev, corner, nxt)
    lane_adjustment = concentric_corner_radius(turn_in, turn_out, dx, base_radius=0.0)
    return reference_anchored_radius(-lane_adjustment, lane_radius)


def widest_coincident_radius(radii: Iterable[float]) -> float:
    """The outermost of several corner radii meeting at one shared vertex.

    Same-line legs a coincidence pass fuses onto one channel each arrive with
    the radius their own handler produced; where they share a turn vertex the
    fused stroke must draw the widest so it nests outside any concentric bundle
    sharing that corner.  Selecting among radii the helper family already
    produced keeps corner sizing centralised in this module rather than
    scattered as inline arithmetic at the fusion site.
    """
    return max(radii)


def shared_leg_radius(radius: float, leg: float, taken: float) -> float:
    """*radius* cut to what a *leg* of that length leaves once the corner at its
    other end takes *taken* of it, and never below zero."""
    return min(radius, max(0.0, leg - taken))


def reference_anchored_radius(
    signed_offset: float,
    base_radius: float,
    *,
    min_radius: float | None = None,
) -> float:
    """Concentric arc radius anchored on a *reference* line, not the innermost.

    ``corner_radius`` anchors the bundle's innermost line at *base_radius* so
    every radius is ``>= base_radius``.  The TOP-entry staircase into a port
    instead anchors a chosen **reference line** (the one kept continuous with
    its bundle-mates at the upstream junction) at *base_radius*, then offsets
    every other line by its signed perpendicular displacement from that
    reference.  Because that reference is interior to the bundle, lines on the
    inside of a turn fall **below** the base radius (``signed_offset < 0``).

    Both forms encode the same concentricity invariant ``radius - displacement
    = const``; they differ only in which line is pinned to *base_radius*.  This
    helper is the single source of truth for the reference-anchored variant.

    Parameters
    ----------
    signed_offset : float
        Perpendicular displacement of this line from the reference line at the
        corner, signed by the inside/outside sense of the turn (positive on the
        outside, negative on the inside).  The reference line itself has
        ``signed_offset == 0`` and therefore radius *base_radius*.
    base_radius : float
        Reference-line radius (the bundle-wide concentric centre offset).
    min_radius : float or None
        Optional floor.  Tight converging jogs onto a shared port point can
        drive ``base_radius + signed_offset`` to zero or below; pass a small
        positive floor (e.g. ``COORD_TOLERANCE``) to keep the arc renderable.
        ``None`` (default) applies no floor.

    Returns
    -------
    float
        ``base_radius + signed_offset`` (clamped up to *min_radius* if given).
    """
    r = base_radius + signed_offset
    if min_radius is not None:
        return max(min_radius, r)
    return r


def outer_lane_radius(
    n_lines: int,
    base_radius: float | None = None,
    offset_step: float = OFFSET_STEP,
) -> float:
    """Arc radius the widest lane of an *n_lines* concentric turn takes.

    The bundle's lanes nest one *offset_step* apart, so the lane on the outside
    of the turn sweeps ``base_radius`` plus the whole bundle width while the
    innermost sweeps the base radius alone.

    This is the runway a turn needs beside the box or junction it leaves: every
    lane's own run falls short of its own arc by the same amount, so a corner
    seated only *base_radius* clear leaves the whole bundle clamped tighter than
    its concentric spacing intends.  A handler seating a corner column measures
    from here rather than from *base_radius*.
    """
    if base_radius is None:
        base_radius = active_curve_radius()
    return reference_anchored_radius(bundle_width(n_lines, offset_step), base_radius)


# ---------------------------------------------------------------------------
# Standard inter-section L-shape (horizontal -> vertical -> horizontal)
# ---------------------------------------------------------------------------


def l_shape_stagger(
    i: int, n: int, vertical: Direction, offset_step: float = OFFSET_STEP
) -> float:
    """Signed lateral offset of line *i* in an *n*-line L-shape vertical channel.

    The ``delta`` half of :func:`l_shape_radii` -- where line *i* sits relative
    to the channel centre -- with no radius computation.  A centreline builder
    derives every corner radius from the geometry it lays out, so a handler that
    only needs to place the channel (not size a hand-rolled arc) takes this.

    Going DOWN, ``i = 0`` is rightmost (positive delta); going UP it is leftmost
    (negative delta), matching :func:`l_shape_radii`'s inside/outside convention.
    """
    if vertical is Direction.D:
        return ((n - 1) / 2 - i) * offset_step
    return (i - (n - 1) / 2) * offset_step


def l_shape_radii(
    i: int,
    n: int,
    vertical: Direction,
    offset_step: float = OFFSET_STEP,
) -> tuple[float, float, float]:
    """Compute offset and radii for a standard inter-section L-shape.

    An L-shape routes ``horizontal -> vertical -> horizontal`` with two
    corners.  The bundle of *n* parallel lines fans out in the vertical
    channel, and each line gets a different radius at each corner so
    the arcs are concentric (nested) rather than overlapping.

    Parameters
    ----------
    i : int
        This line's index within the bundle (0 to n-1), as assigned by
        ``compute_bundle_info()``.
    n : int
        Total number of lines in the bundle.
    vertical : Direction
        ``Direction.D`` if the vertical segment goes downward (dy > 0),
        ``Direction.U`` if it goes upward.
    offset_step : float
        Spacing between adjacent lines in the bundle.

    The innermost line turns at the active corner radius.

    Returns
    -------
    delta : float
        X offset from the vertical channel center for this line.
    r_first : float
        Corner radius at the first turn (horizontal -> vertical).
    r_second : float
        Corner radius at the second turn (vertical -> horizontal).

    Geometry
    --------
    Going DOWN (right -> down -> right):
        * Corner 1 is a CW turn.  i=0 is placed rightmost (positive
          delta), on the outside, so it gets the largest radius.
        * Corner 2 is a CCW turn.  The rightmost line is now on the
          inside, so it gets the smallest radius.

    Going UP (right -> up -> right):
        * Corner 1 is a CCW turn.  i=0 is placed leftmost (negative
          delta), on the inside, so it gets the smallest radius.
        * Corner 2 is a CW turn.  The leftmost line is now on the
          outside, so it gets the largest radius.
    """
    off = (n - 1 - i) * offset_step
    max_off = (n - 1) * offset_step
    delta = l_shape_stagger(i, n, vertical, offset_step)
    base_radius = active_curve_radius()

    if vertical is Direction.D:
        # Corner 1 (CW):  rightmost = outside -> largest radius
        r_first = corner_radius(off, max_off, outside=True, base_radius=base_radius)
        # Corner 2 (CCW): rightmost = inside  -> smallest radius
        r_second = corner_radius(off, max_off, outside=False, base_radius=base_radius)
    else:
        # Corner 1 (CCW): leftmost = inside  -> smallest radius
        r_first = corner_radius(off, max_off, outside=False, base_radius=base_radius)
        # Corner 2 (CW):  leftmost = outside -> largest radius
        r_second = corner_radius(off, max_off, outside=True, base_radius=base_radius)

    return delta, r_first, r_second


# ---------------------------------------------------------------------------
# Bypass (two back-to-back L-shapes)
# ---------------------------------------------------------------------------


def bypass_stagger(
    g1_i: int,
    g1_n: int,
    g2_i: int,
    g2_n: int,
    horizontal: Direction,
    offset_step: float = OFFSET_STEP,
    gap1_vertical: Direction = Direction.D,
    gap2_vertical: Direction = Direction.U,
) -> tuple[float, float]:
    """Per-line lateral offsets at a U-shaped bypass's two vertical channels.

    A bypass is two back-to-back L-shapes (corners 1-2 at gap1, corners 3-4 at
    gap2).  The centreline builder derives every corner radius from the geometry,
    so a handler needs only where each line sits in the two channels: this
    returns ``(delta1, delta2)``, the :func:`l_shape_stagger` of each gap.

    Parameters
    ----------
    g1_i, g1_n : int
        Line index and bundle size at gap1.
    g2_i, g2_n : int
        Line index and bundle size at gap2.
    horizontal : Direction
        ``Direction.R`` when the bypass travels rightward (dx > 0),
        ``Direction.L`` when leftward.  Left-going bypasses mirror the
        inside/outside assignment.
    gap1_vertical : Direction
        Vertical direction at gap1.  ``Direction.D`` when the trunk is below the
        source (standard case), ``Direction.U`` when the source is below it.
    gap2_vertical : Direction
        Vertical direction at gap2.  Almost always ``Direction.U``.
    """
    # For left-going bypasses, reverse indices so the outside/inside
    # assignment matches the mirrored corner geometry.
    going_right = horizontal is Direction.R
    g1_idx = g1_i if going_right else g1_n - 1 - g1_i
    g2_idx = g2_i if going_right else g2_n - 1 - g2_i
    delta1 = l_shape_stagger(g1_idx, g1_n, gap1_vertical, offset_step)
    delta2 = l_shape_stagger(g2_idx, g2_n, gap2_vertical, offset_step)
    return delta1, delta2
