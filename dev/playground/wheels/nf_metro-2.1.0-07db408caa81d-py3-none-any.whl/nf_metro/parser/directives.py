"""Parsing and dispatch of ``%%metro`` directives.

Each directive maps a ``key: value`` line onto the :class:`MetroGraph` (or the
enclosing section). Graph-wide directives are routed through a registry; the
section-scoped (entry/exit/direction/number) and file/files/dir icon directives
need extra context and are handled by :func:`_apply_directive`.
"""

from __future__ import annotations

import re
import warnings
from collections.abc import Callable, Collection, Iterator
from typing import Literal

from nf_metro.options import (
    INVALID,
    LAYOUT_OPTIONS,
    LayoutOption,
    coerce,
    is_line_order,
)
from nf_metro.parser.grammar import (
    _IDENTIFIER_CHARSET,
    _normalize_multiline_text,
    _split_csv,
    _unquote,
)
from nf_metro.parser.model import (
    FLOW_DIRECTIONS,
    LINE_INACTIVE_KEYWORD,
    MARKER_FILL_OPEN,
    MARKER_FILL_SOLID,
    MARKER_SHAPE_CIRCLE,
    VALID_ICON_TYPES,
    VALID_LINE_STYLES,
    VALID_MARKER_SHAPES,
    Interchange,
    LineSpread,
    MarkerLegendEntry,
    MarkerStyle,
    MetroGraph,
    MetroLine,
    PortSide,
    StationGroup,
)


def _warn_directive(key: str, message: str) -> None:
    """Warn about a %%metro directive; every directive warning uses this."""
    warnings.warn(f"%%metro {key}: {message}", stacklevel=2)


def _warn_malformed(key: str, value: str, expected: str) -> None:
    """Warn that a directive's payload is unusable and is being ignored."""
    _warn_directive(key, f"ignoring {value!r}; expected {expected}")


def _split_fields(value: str) -> list[str]:
    """Split a ``|``-delimited directive body into stripped fields.

    Empty fields are kept (so positional access by index stays valid); only the
    surrounding whitespace of each field is removed.
    """
    return [field.strip() for field in value.split("|")]


def _dir_title(value: str, graph: MetroGraph) -> None:
    graph.title = value


def _dir_style(value: str, graph: MetroGraph) -> None:
    # Imported here because the theme registry reaches the render package,
    # which imports the parser back.
    from nf_metro.themes import STYLE_NAMES

    if value.strip().lower() not in STYLE_NAMES:
        _warn_malformed("style", value, "/".join(sorted(STYLE_NAMES)))
        return
    graph.style = value


# The two display modes a theme can render in, shared with the per-output
# `mode=` override below.
_MODE_CHOICES: tuple[str, ...] = ("light", "dark")


def _dir_mode(value: str, graph: MetroGraph) -> None:
    mode = value.strip().lower()
    if mode not in _MODE_CHOICES:
        _warn_malformed("mode", value, "light/dark")
        return
    graph.mode = mode


def _dir_logo(value: str, graph: MetroGraph) -> None:
    if "|" in value:
        parts = _split_fields(value)
        graph.logo_path_light = parts[0]
        graph.logo_path_dark = parts[1] if len(parts) > 1 else ""
    else:
        graph.logo_path = value


# Render options one ``%%metro output:`` declaration may override for itself,
# mapped to how each one's value is read. Deliberately narrow: every key here
# changes how the map is *drawn*, never what the map *is*, so a file declaring
# four outputs still declares one diagram. Anything structural stays graph-wide,
# where a reader sees it once.
_OUTPUT_OVERRIDE_KINDS: dict[str, str] = {
    "animate": "bool",
    "mode": "mode",
    "theme": "theme",
    "scale": "float",
    "raster_width": "int",
}

# Override tokens are separated by commas, whitespace, or both.
_OUTPUT_OVERRIDE_SEP = re.compile(r"[,\s]+")

# Whitespace hugging a `=` is part of the token's own separator, not the
# token boundary, so `mode = dark` reads as one token rather than three.
_OUTPUT_OVERRIDE_EQ_SPACE = re.compile(r"\s*=\s*")


def _output_override_value(key: str, raw: str) -> object | None:
    """Coerce one override's payload, or ``None`` when it is unusable.

    Every kind is validated through :func:`nf_metro.options.coerce`, the same
    path every other ``%%metro`` numeric/choice directive and its equivalent
    CLI flag already go through. ``False`` is a legitimate result
    (``animate=false``), so callers test the outcome against ``None`` rather
    than for truthiness.
    """
    kind = _OUTPUT_OVERRIDE_KINDS[key]
    text = raw.strip().lower()
    if kind == "bool" and text == "":
        # A bare flag ("animate") means on; coerce's own bool kind reads an
        # empty payload as off, which only applies to an explicit `key=`.
        return True
    if kind == "mode":
        opt = LayoutOption(name=key, kind="choice", choices=_MODE_CHOICES, help="")
    elif kind == "theme":
        # Imported here, not at module scope, because the theme registry
        # reaches the render package, which imports the parser back.
        from nf_metro.themes import STYLE_NAMES

        opt = LayoutOption(name=key, kind="choice", choices=tuple(STYLE_NAMES), help="")
    elif kind in ("float", "int"):
        numeric_kind: Literal["float", "int"] = "float" if kind == "float" else "int"
        opt = LayoutOption(name=key, kind=numeric_kind, sign="positive", help="")
    else:
        opt = LayoutOption(name=key, kind="bool", help="")
    value, _ = coerce(opt, text)
    return None if value is INVALID else value


def _parse_output_overrides(spec: str) -> dict[str, object]:
    """Read the ``key=value``/bare-flag tokens right of an output's ``|``.

    Each bad token is warned about and dropped on its own, so one typo
    doesn't silently discard the overrides beside it (nor the output itself,
    which still renders under the run's global options).
    """
    overrides: dict[str, object] = {}
    normalized = _OUTPUT_OVERRIDE_EQ_SPACE.sub("=", spec.strip())
    for token in _OUTPUT_OVERRIDE_SEP.split(normalized):
        if not token:
            continue
        name, sep, raw = token.partition("=")
        key = name.strip().lower()
        if key not in _OUTPUT_OVERRIDE_KINDS:
            _warn_directive(
                "output",
                f"ignoring unknown override {token!r}; expected one of "
                + ", ".join(sorted(_OUTPUT_OVERRIDE_KINDS)),
            )
            continue
        if not sep and _OUTPUT_OVERRIDE_KINDS[key] != "bool":
            _warn_directive("output", f"ignoring {token!r}; expected {key}=<value>")
            continue
        value = _output_override_value(key, raw)
        if value is None:
            _warn_directive("output", f"ignoring {token!r}; bad value for {key}")
            continue
        overrides[key] = value
    return overrides


def _dir_output(value: str, graph: MetroGraph) -> None:
    """Record ``%%metro output: path[, path...] [| override...]``: the default
    outputs used by ``nf-metro render`` when no ``-o`` is given.

    Repeating the directive accumulates, so a map may declare its formats on
    one line or split across several. A path already declared is skipped
    rather than duplicated, so a repeated declaration can't schedule the same
    output to be rendered (and reported) twice. The paths are stored exactly
    as written; the CLI resolves each one against the .mmd's own directory.

    Everything right of the first ``|`` is that line's per-output render
    overrides (see :data:`_OUTPUT_OVERRIDE_KINDS`), applied to every path on
    the line, which is how one map declares a static SVG, an animated SVG and
    a light/dark PNG pair in a single ``nf-metro render`` pass.
    """
    spec, sep, override_spec = value.partition("|")
    paths = _split_csv(spec)
    if not paths:
        _warn_malformed("output", value, "'path[, path...] [| override, ...]'")
        return
    overrides = _parse_output_overrides(override_spec) if sep else {}
    declared = {p for p, _ in graph.declared_outputs}
    for path in paths:
        if path in declared:
            continue
        declared.add(path)
        # A copy per path: the list's entries are independent records, and a
        # later consumer mutating one must not reach its line-mates.
        graph.declared_outputs.append((path, dict(overrides)))


def _dir_off_track(value: str, graph: MetroGraph) -> None:
    station_ids = _split_csv(value)
    if not station_ids:
        _warn_malformed("off_track", value, "'station1[, station2, ...]'")
        return
    graph._pending_off_track.extend(station_ids)


def _dir_process(value: str, graph: MetroGraph) -> None:
    """Parse ``%%metro process: station_id | regex``.

    Maps a station to the Nextflow process name(s) it represents, for the
    live-progress server and the check-mapping linter. The whole field after
    ``|`` is one regular expression (no comma splitting, so quantifiers like
    ``{1,3}`` are safe); repeat the directive to attach several patterns to one
    station. The regex is matched against the fully-qualified process name, so
    ``FASTQC`` matches ``NFCORE_RNASEQ:RNASEQ:FASTQC``.
    """
    station_id, sep, pattern = value.partition("|")
    station_id, pattern = station_id.strip(), pattern.strip()
    if not sep or not station_id or not pattern:
        _warn_malformed("process", value, "'station_id | regex'")
        return
    try:
        re.compile(pattern)
    except re.error as exc:
        _warn_directive("process", f"invalid regex {pattern!r}: {exc}")
        return
    graph._pending_process.append((station_id, pattern))


_COLOR_FUNCTION = re.compile(r"[A-Za-z-]+\(.*\)\Z")
_COLOR_KEYWORDS = frozenset({"currentcolor", "transparent", "none"})

_LINE_ID_PATTERN = re.compile(_IDENTIFIER_CHARSET)
"""Built from the same charset as the ``NAME`` grammar token for node/section
ids (:data:`nf_metro.parser.grammar._IDENTIFIER_CHARSET`).

A declared line id lands in SVG ``class=``/``data-*`` attributes verbatim, so
constraining it here (rather than escaping at every emission site) rules out
attribute-injection through this vector entirely.
"""


def _is_color(value: str) -> bool:
    """True when *value* is a colour an SVG stroke can resolve.

    Any functional notation and the three CSS keywords are accepted on shape
    alone, so a colour syntax this check does not model (``var()``,
    ``light-dark()``, ``oklch()``) is never called wrong; hex forms and named
    colours are resolved by Pillow. A caller warns on a False and keeps the
    value, since being unmodelled is not the same as being invalid.
    """
    text = value.strip()
    if text.lower() in _COLOR_KEYWORDS or _COLOR_FUNCTION.match(text):
        return True
    # Deferred so a parse-only command (``validate``, ``info``) loads Pillow
    # only for a map that reaches this branch.
    from PIL import ImageColor

    try:
        ImageColor.getrgb(text)
    except ValueError:
        return False
    return True


def _dir_line(value: str, graph: MetroGraph) -> None:
    parts = _split_fields(value)
    line_id = parts[0]
    if len(parts) < 3 or not all(parts[:3]):
        _warn_malformed(
            "line",
            value,
            f"'id | name | #color' [| style [| {LINE_INACTIVE_KEYWORD}]]",
        )
        return
    if not _LINE_ID_PATTERN.fullmatch(line_id):
        _warn_directive(
            "line",
            f"id {line_id!r} is invalid; ignoring the declaration. Line ids "
            "must match [a-zA-Z_][a-zA-Z0-9_]* (the same charset as node and "
            "section ids), since they land in SVG class/data-* attributes "
            "verbatim",
        )
        return
    if line_id in graph.lines:
        _warn_directive(
            "line",
            f"{line_id!r} is already declared; ignoring the redeclaration",
        )
        return
    if not _is_color(parts[2]):
        _warn_directive(
            "line",
            f"{line_id!r} colour {parts[2]!r} is not a recognised colour; "
            "expected a hex value like '#4caf50'",
        )
    style = "solid"
    if len(parts) >= 4 and parts[3]:
        raw_style = parts[3].lower()
        if raw_style in VALID_LINE_STYLES:
            style = raw_style
        else:
            _warn_malformed("line style", parts[3], "/".join(VALID_LINE_STYLES))
    default_inactive = False
    if len(parts) >= 5 and parts[4]:
        raw_state = parts[4].lower()
        if raw_state == LINE_INACTIVE_KEYWORD:
            default_inactive = True
        else:
            _warn_malformed("line state", parts[4], LINE_INACTIVE_KEYWORD)
    graph.add_line(
        MetroLine(
            id=line_id,
            display_name=parts[1],
            color=parts[2],
            style=style,
            default_inactive=default_inactive,
        )
    )


def _parse_icon_directive(icon_type: str, value: str, graph: MetroGraph) -> None:
    """Parse %%metro file:/files:/dir: station_id | labels [| name [| options]].

    Records a pending terminus designation; each comma-separated label becomes
    one icon, optionally captioned by the third field and bannered when the
    fourth field's options include ``banner``.
    """
    parts = _split_fields(value)
    if len(parts) < 2:
        _warn_malformed(icon_type, value, "'station_id | labels [| name [| options]]'")
        return
    station_id = parts[0]
    labels = [_normalize_multiline_text(label) for label in _split_csv(parts[1])]
    if not labels:
        _warn_malformed(icon_type, value, "'station_id | labels [| name [| options]]'")
        return
    name = _normalize_multiline_text(parts[2]) if len(parts) >= 3 else ""
    options = {o.lower() for o in _split_csv(parts[3])} if len(parts) >= 4 else set()
    banner = "banner" in options
    graph._pending_terminus.setdefault(station_id, []).extend(
        (label, icon_type, name, banner) for label in labels
    )


def _parse_port_hint(
    value: str,
    graph: MetroGraph,
    section_id: str,
    is_entry: bool,
) -> None:
    """Parse %%metro entry:/exit: and store as a hint on the Section.

    Does NOT create Port objects - those are created later in _resolve_sections
    based on actual inter-section edges.
    """
    key = "entry" if is_entry else "exit"
    parts = _split_fields(value)
    if len(parts) < 2:
        _warn_malformed(key, value, "'side | line1, line2'")
        return

    side_str = parts[0].lower()
    side_map = {
        "left": PortSide.LEFT,
        "right": PortSide.RIGHT,
        "top": PortSide.TOP,
        "bottom": PortSide.BOTTOM,
    }
    side = side_map.get(side_str)
    if side is None:
        _warn_malformed(key, side_str, "a side (left/right/top/bottom)")
        return

    line_ids = _split_csv(parts[1])

    section = graph.sections.get(section_id)
    if section:
        if is_entry:
            section.entry_hints.append((side, line_ids))
        else:
            section.exit_hints.append((side, line_ids))


def _parse_grid_directive(value: str, graph: MetroGraph) -> None:
    """Parse %%metro grid: section_ids | col,row[,rowspan[,colspan]] directive.

    The first field may name several comma-separated sections; they share one
    cell and pack side-by-side along the flow axis (see ``cell_packs``).
    """
    parts = _split_fields(value)
    coords = parts[1].split(",") if len(parts) >= 2 else []
    if len(parts) < 2 or len(coords) < 2:
        _warn_malformed("grid", value, "'section_ids | col,row[,rowspan[,colspan]]'")
        return

    member_ids = _split_csv(parts[0])
    if not member_ids:
        _warn_malformed("grid", value, "'section_ids | col,row[,rowspan[,colspan]]'")
        return
    try:
        col = int(coords[0].strip())
        row = int(coords[1].strip())
        rowspan = int(coords[2].strip()) if len(coords) >= 3 else 1
        colspan = int(coords[3].strip()) if len(coords) >= 4 else 1
    except ValueError:
        _warn_malformed("grid", value, "integer col,row[,rowspan[,colspan]]")
        return
    for section_id in member_ids:
        cell = (col, row, rowspan, colspan)
        graph.grid_overrides[section_id] = cell
        graph.layout_provenance.record_authored_grid(section_id, cell)
    if len(member_ids) > 1:
        graph.cell_packs[col, row] = member_ids


_LEGEND_KEYWORDS = ("bl", "br", "tl", "tr", "bottom", "right", "none")


def _parse_xy(text: str) -> tuple[float, float] | None:
    """Parse a ``x,y`` pair into floats, or None if it is not a number pair."""
    if "," not in text:
        return None
    x_str, _, y_str = text.partition(",")
    try:
        return (float(x_str.strip()), float(y_str.strip()))
    except ValueError:
        return None


def apply_legend_directive(value: str, graph: MetroGraph) -> None:
    """Parse the %%metro legend: directive positioning the legend+logo block.

    Grammar (the keyword forms stay content-anchored with the content-overlap
    fallback; the qualifier and absolute forms pin the block exactly):

        legend: <keyword>              keyword (bl/br/tl/tr/bottom/right/none)
        legend: <keyword> | canvas     anchor the keyword to the canvas frame
        legend: <keyword> | <dx>,<dy>  nudge the keyword anchor by an offset
        legend: <x>,<y>                absolute top-left coordinates
    """
    # Reset modifiers so a re-declared directive starts clean.
    graph.legend_anchor = "content"
    graph.legend_offset = None
    graph.legend_at = None

    head, sep, qualifier = value.partition("|")
    head = head.strip().lower()
    qualifier = qualifier.strip().lower()

    coords = _parse_xy(head)
    if coords is not None:
        graph.legend_at = coords
        graph.legend_position = "free"
        if sep:
            _warn_directive(
                "legend",
                f"qualifier {qualifier!r} ignored with absolute coordinates",
            )
        return

    if head not in _LEGEND_KEYWORDS:
        _warn_directive(
            "legend",
            f"unknown position {head!r}; expected one of "
            f"{'/'.join(_LEGEND_KEYWORDS)} or 'x,y'. Ignoring",
        )
        return
    graph.legend_position = head

    if not qualifier:
        return
    if qualifier == "canvas":
        graph.legend_anchor = "canvas"
        return
    offset = _parse_xy(qualifier)
    if offset is not None:
        graph.legend_offset = offset
    else:
        _warn_directive(
            "legend",
            f"unknown qualifier {qualifier!r}; expected 'canvas' or 'dx,dy'. Ignoring",
        )


def _parse_group_directive(value: str, graph: MetroGraph) -> None:
    """Parse %%metro group: Label | station1, station2[, ...] [| above|below].

    Stores an annotative caption spanning the listed stations.  The optional
    third field selects whether the caption renders ``below`` (default) or
    ``above`` the spanned stations.  It never moves a station, but a ``below``
    band claims room inside its section's box, growing the bottom edge that
    bounds the row corridor beneath it.
    """
    parts = _split_fields(value)
    if len(parts) < 2:
        _warn_directive(
            "group",
            f"{value!r} needs 'Label | station1, station2'. Ignoring",
        )
        return
    label = _unquote(parts[0])
    station_ids = _split_csv(parts[1])
    if not label or not station_ids:
        _warn_directive(
            "group",
            f"{value!r} needs a label and at least one station. Ignoring",
        )
        return
    position: Literal["above", "below"] = "below"
    if len(parts) >= 3:
        raw_pos = parts[2].lower()
        if raw_pos == "above":
            position = "above"
        elif raw_pos == "below":
            position = "below"
        elif raw_pos:
            _warn_directive(
                "group",
                f"position {raw_pos!r} not recognised; expected "
                "'above' or 'below'. Using 'below'",
            )
    graph.groups.append(
        StationGroup(label=label, station_ids=station_ids, position=position)
    )


def _parse_interchange_directive(value: str, graph: MetroGraph) -> None:
    """Parse %%metro interchange: node_id | rail-1 lines | rail-2 lines [| ...].

    Declares ``node_id`` a cross-track interchange: each pipe-separated group is
    one rail of the interchange, carrying the comma-separated lines listed in
    it.  The node is expanded into one sub-station per rail in
    :func:`resolve._expand_interchanges`, so the lines pass through on their own
    tracks and the step renders as a single connector glyph.  Needs at least two
    rails; a malformed directive is warned about and ignored.
    """
    parts = _split_fields(value)
    if len(parts) < 3:
        _warn_directive(
            "interchange",
            f"{value!r} needs 'node_id | rail-1 lines | rail-2 lines'. Ignoring",
        )
        return
    node_id = parts[0].strip()
    rails = [_split_csv(p) for p in parts[1:]]
    if not node_id or any(not rail for rail in rails):
        _warn_directive(
            "interchange",
            f"{value!r} needs a node id and at least one line per rail. Ignoring",
        )
        return
    graph.interchanges.append(Interchange(node_id=node_id, rails=rails))


def _parse_legend_combo_directive(value: str, graph: MetroGraph) -> None:
    """Parse %%metro legend_combo: lineA, lineB[, ...] | Display Label.

    The named lines render as a single combined legend row and (in rail mode)
    share a single rail slot. Only the payload's shape is checked here; the
    member line ids are resolved by :func:`_resolve_legend_combos`.
    """
    parts = value.split("|", 1)
    if len(parts) != 2:
        _warn_directive(
            "legend_combo",
            f"invalid {value!r}; expected 'lineA, lineB | Display Label'",
        )
        return
    ids_raw, label = parts[0], parts[1].strip()
    named = _split_csv(ids_raw)
    line_ids = list(dict.fromkeys(named))
    if len(line_ids) < len(named):
        _warn_directive(
            "legend_combo",
            f"{value!r} names a line more than once; keeping one of each",
        )
    if len(line_ids) < 2 or not label:
        _warn_directive(
            "legend_combo",
            f"invalid {value!r}; expected at least two line IDs and a non-empty label",
        )
        return
    graph._pending_legend_combos.append((line_ids, label))


def _parse_marker_style(key: str, spec: str) -> MarkerStyle | None:
    """Parse a ``shape, fill`` marker spec into a MarkerStyle.

    ``shape`` defaults to ``circle`` and ``fill`` to ``solid`` when omitted.
    An unknown shape is rejected (returns None with a warning); any fill
    string other than ``open``/``solid`` is taken as a literal colour.
    """
    parts = [p.strip() for p in spec.split(",")]
    shape = parts[0].lower() if parts and parts[0] else MARKER_SHAPE_CIRCLE
    fill = parts[1] if len(parts) >= 2 and parts[1] else MARKER_FILL_SOLID
    if shape not in VALID_MARKER_SHAPES:
        _warn_directive(
            key,
            f"unknown shape {shape!r}; expected one of "
            f"{'/'.join(VALID_MARKER_SHAPES)}. Ignoring",
        )
        return None
    # Normalise the fill keywords to lowercase; leave literal colours as-is.
    if fill.lower() in (MARKER_FILL_OPEN, MARKER_FILL_SOLID):
        fill = fill.lower()
    return MarkerStyle(shape=shape, fill=fill)


def _parse_marker_directive(value: str, graph: MetroGraph) -> None:
    """Parse ``%%metro marker: node_id | shape, fill``."""
    node_part, sep, style_part = value.partition("|")
    node_id = node_part.strip()
    if not node_id:
        _warn_malformed("marker", value, "'node_id | shape, fill'")
        return
    style = _parse_marker_style("marker", style_part.strip() if sep else "")
    if style is not None:
        graph._pending_markers[node_id] = style


def _parse_marker_legend_directive(value: str, graph: MetroGraph) -> None:
    """Parse ``%%metro marker_legend: shape, fill | Caption``."""
    style_part, _, caption = value.partition("|")
    caption = caption.strip()
    if not caption:
        _warn_malformed("marker_legend", value, "'shape, fill | Caption'")
        return
    style = _parse_marker_style("marker_legend", style_part.strip())
    if style is not None:
        graph.marker_legend.append(MarkerLegendEntry(style=style, caption=caption))


def _parse_line_spread_directive(value: str, graph: MetroGraph) -> None:
    """Parse %%metro line_spread: <mode>[ | section[, section...]].

    Bare ``line_spread: <mode>`` sets the graph-wide default; the piped form
    ``line_spread: <mode> | sectionA, sectionB`` records a per-section override
    that wins over the default for those sections. ``<mode>`` is one of
    ``bundle`` / ``centered`` / ``rails``; an unrecognised mode is warned about
    and ignored.
    """
    mode_raw, sep, sids_raw = value.partition("|")
    try:
        mode = LineSpread(mode_raw.strip().lower())
    except ValueError:
        valid = ", ".join(m.value for m in LineSpread)
        _warn_directive(
            "line_spread",
            f"invalid mode {mode_raw.strip()!r}; expected one of {valid}",
        )
        return
    section_ids = _split_csv(sids_raw)
    if section_ids:
        for sid in section_ids:
            graph.line_spread_overrides[sid] = mode
    elif sep:
        _warn_malformed("line_spread", value, "'<mode> | section[, section...]'")
    else:
        graph.line_spread = mode


def _make_layout_option_handler(
    opt: LayoutOption,
) -> Callable[[str, MetroGraph], None]:
    """Build the directive handler for a registry option.

    The handler parses the payload via :func:`coerce`, writing the option's
    graph field on success or warning (and leaving the default) on a malformed
    value.  This is the directive half of the single-definition cascade in
    :mod:`nf_metro.options`; the CLI half lives in :mod:`nf_metro.cli`.
    """

    def handler(value: str, graph: MetroGraph) -> None:
        result, expected = coerce(opt, value)
        if result is INVALID:
            _warn_malformed(opt.name, value, expected)
        else:
            setattr(graph, opt.target_attr, result)
            if opt.name == "line_order":
                assert is_line_order(result)
                graph.layout_provenance.record_authored_line_order(result)

    return handler


# Graph-wide directives, keyed by exact name. The simple scalar/bool/enum
# knobs are generated from the LAYOUT_OPTIONS registry (shared with the CLI);
# the bespoke handlers below carry grammar the generic registry can't express.
# Section-scoped (entry/exit/direction/number) and icon (file/files/dir) keys are
# dispatched separately in _apply_directive / _apply_scoped_directive.
_GLOBAL_DIRECTIVE_HANDLERS: dict[str, Callable[[str, MetroGraph], None]] = {
    opt.name: _make_layout_option_handler(opt) for opt in LAYOUT_OPTIONS
}
_GLOBAL_DIRECTIVE_HANDLERS.update(
    {
        "title": _dir_title,
        "style": _dir_style,
        "mode": _dir_mode,
        "logo": _dir_logo,
        "output": _dir_output,
        "line": _dir_line,
        "off_track": _dir_off_track,
        "process": _dir_process,
        "grid": _parse_grid_directive,
        "line_spread": _parse_line_spread_directive,
        "legend_combo": _parse_legend_combo_directive,
        "legend": apply_legend_directive,
        "group": _parse_group_directive,
        "interchange": _parse_interchange_directive,
        "marker_legend": _parse_marker_legend_directive,
        "marker": _parse_marker_directive,
    }
)

# Directives that act on the enclosing subgraph rather than the whole graph.
_SCOPED_DIRECTIVES = ("entry", "exit", "direction", "number")


def _apply_scoped_directive(
    key: str, value: str, graph: MetroGraph, section_id: str | None
) -> None:
    """Apply a section-scoped directive (entry/exit/direction/number).

    These only mean anything inside a subgraph; outside one they are warned
    about and ignored.
    """
    if section_id is None or section_id not in graph.sections:
        _warn_directive(key, "must appear inside a subgraph; ignoring")
    elif key == "direction":
        direction = value.upper()
        if direction in FLOW_DIRECTIONS:
            graph.sections[section_id].direction = direction
            graph.layout_provenance.record_authored_direction(section_id, direction)
        else:
            _warn_malformed("direction", value, "LR/RL/TB/BT")
    elif key == "number":
        try:
            number = int(value)
        except ValueError:
            _warn_malformed("number", value, "a positive integer")
            return
        if number < 1:
            _warn_malformed("number", value, "a positive integer")
            return
        graph.sections[section_id].number_override = number
    else:
        _parse_port_hint(value, graph, section_id, is_entry=key == "entry")


def _apply_directive(
    key: str,
    value: str,
    graph: MetroGraph,
    current_section_id: str | None,
) -> None:
    """Apply one ``%%metro`` directive by its exact key.

    Routes to the section-scoped handler, the file/files/dir icon directive, or
    the graph-wide registry. An unknown key is warned about and ignored.
    """
    if key in _SCOPED_DIRECTIVES:
        _apply_scoped_directive(key, value, graph, current_section_id)
    elif key in VALID_ICON_TYPES:
        _parse_icon_directive(key, value, graph)
    elif handler := _GLOBAL_DIRECTIVE_HANDLERS.get(key):
        handler(value, graph)
    else:
        _warn_directive(key, "unknown directive; ignoring")


IdKind = Literal["station", "section", "line"]


def _directive_references(graph: MetroGraph) -> Iterator[tuple[str, IdKind, str]]:
    """Yield ``(directive key, id kind, id)`` for every id a directive names.

    Covers the directives whose payload points at something declared elsewhere
    in the source. The ``interchange:`` node id is resolved by the expansion
    that consumes it and the ``legend_combo:`` members by
    :func:`_resolve_legend_combos`, both of which report their own unknowns.
    """
    for station_id in graph._pending_off_track:
        yield "off_track", "station", station_id
    for station_id in graph._pending_markers:
        yield "marker", "station", station_id
    for station_id, _pattern in graph._pending_process:
        yield "process", "station", station_id
    for station_id, entries in graph._pending_terminus.items():
        for _label, icon_type, _name, _banner in entries:
            yield icon_type, "station", station_id
    for group in graph.groups:
        for station_id in group.station_ids:
            yield "group", "station", station_id
    for section_id in graph.grid_overrides:
        yield "grid", "section", section_id
    for section_id in graph.line_spread_overrides:
        yield "line_spread", "section", section_id
    for interchange in graph.interchanges:
        for rail in interchange.rails:
            for line_id in rail:
                yield "interchange", "line", line_id
    for section in graph.sections.values():
        hints = (("entry", section.entry_hints), ("exit", section.exit_hints))
        for key, side_hints in hints:
            for _side, line_ids in side_hints:
                for line_id in line_ids:
                    yield key, "line", line_id


def _warn_unresolved_references(graph: MetroGraph) -> None:
    """Warn about directives naming a station, section or line the map lacks.

    Must run once the whole source has been applied, because a directive may
    precede the node or subgraph it names.
    """
    known: dict[IdKind, Collection[str]] = {
        "station": graph.stations.keys(),
        "section": graph.sections.keys(),
        "line": graph.lines.keys(),
    }
    for key, kind, ref_id in dict.fromkeys(_directive_references(graph)):
        if ref_id not in known[kind]:
            _warn_directive(key, f"unknown {kind} id {ref_id!r}; ignoring")


def _resolve_legend_combos(graph: MetroGraph) -> None:
    """Resolve buffered ``%%metro legend_combo:`` members into ``legend_combos``.

    An unknown member is dropped with a warning and the rest kept; a combo left
    with fewer than two known lines is dropped whole.
    """
    for line_ids, label in graph._pending_legend_combos:
        known = [lid for lid in line_ids if lid in graph.lines]
        if unknown := [lid for lid in line_ids if lid not in graph.lines]:
            _warn_directive(
                "legend_combo",
                f"{label!r} references unknown line(s) "
                f"{', '.join(unknown)}; ignoring those",
            )
        if len(known) < 2:
            _warn_directive(
                "legend_combo",
                f"{label!r} has fewer than two known lines; ignoring",
            )
            continue
        graph.legend_combos.append((tuple(known), label))


def _deduplicate_section_number_overrides(graph: MetroGraph) -> None:
    """Keep the first section assigned each authored badge number."""
    owners: dict[int, str] = {}
    for section in graph.sections.values():
        number = section.number_override
        if number is None:
            continue
        if conflict := owners.get(number):
            _warn_directive(
                "number",
                f"{number} is already assigned to section {conflict!r}; ignoring",
            )
            section.number_override = None
        else:
            owners[number] = section.id
